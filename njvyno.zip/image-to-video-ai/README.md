# 🎬 Image to Video AI Generator

Transform your images into stunning videos using AI. Built with Next.js 15, React 19, and the z-ai-web-dev-sdk.

![Next.js](https://img.shields.io/badge/Next.js-16.1.1-black)
![React](https://img.shields.io/badge/React-19-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)

## ✨ Features

- 📷 **All Image Formats** - JPG, PNG, WEBP, GIF, BMP, TIFF, HEIC, AVIF supported
- 🔄 **Auto-Conversion** - Images are automatically converted and optimized
- ✨ **AI Enhancement** - Prompts are auto-enhanced for better results
- ⏱️ **Progress Tracking** - Real-time progress with stage indicators
- 🎛️ **Performance Modes** - Fast (30-60s), Balanced (60-120s), Quality (90-180s)
- 📜 **Generation History** - Keep track of all your generated videos
- ⭐ **Favorites** - Save your favorite generations
- 📊 **Prompt Analysis** - Health check and quality scoring for prompts

## 🚀 Deploy to Vercel

### One-Click Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Click the button above
2. Sign in to Vercel (free)
3. Import this repository
4. Click "Deploy"
5. Get your permanent URL like `https://your-app.vercel.app`

## 🛠️ Local Development

```bash
# Install dependencies
bun install

# Run development server
bun run dev

# Open http://localhost:3000
```

## 📁 Project Structure

```
├── src/
│   ├── app/
│   │   ├── api/video/
│   │   │   ├── generate/route.ts    # Video generation API
│   │   │   └── status/[taskId]/route.ts  # Status polling API
│   │   ├── layout.tsx
│   │   ├── page.tsx                 # Main page
│   │   └── globals.css
│   ├── components/
│   │   ├── ui/                      # shadcn/ui components
│   │   ├── image-upload.tsx
│   │   ├── prompt-section.tsx
│   │   ├── generation-settings.tsx
│   │   ├── generation-progress.tsx
│   │   ├── video-output.tsx
│   │   └── ...
│   ├── lib/
│   │   ├── image-utils.ts           # Image processing
│   │   ├── prompt-enhancer.ts       # AI prompt enhancement
│   │   ├── prompt-utils.ts          # Prompt utilities
│   │   └── video-utils.ts           # Video utilities
│   ├── store/
│   │   └── video-store.ts           # Zustand state management
│   └── types/
│       └── video.ts                 # TypeScript types
├── public/
├── package.json
├── next.config.ts
├── tailwind.config.ts
└── vercel.json
```

## ⚙️ Configuration

No environment variables required! The app uses the built-in z-ai-web-dev-sdk.

## 🎮 Usage

1. **Upload an image** - Drag & drop or click to upload any image format
2. **Write a prompt** - Describe the motion you want (e.g., "woman smiling, natural smile forming")
3. **Select performance mode** - Fast, Balanced, or Quality
4. **Click Generate** - Watch the progress and wait for your video
5. **Download or Share** - Get your generated video

## 📝 Prompt Tips

- Be specific about motion: "head turning slowly left"
- Add timing: "slowly", "gradually", "smoothly"
- Include details: "natural smile", "gentle blink"
- The AI will auto-enhance your prompt for better results

## 🔧 Tech Stack

- **Framework**: Next.js 15 with App Router
- **UI**: React 19, TypeScript, Tailwind CSS
- **Components**: shadcn/ui
- **State**: Zustand with localStorage persistence
- **AI**: z-ai-web-dev-sdk for video generation

## 📄 License

MIT License - Use it however you want!

---

Made with ❤️ using AI
