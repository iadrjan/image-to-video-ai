'use client';

import { useCallback, useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Download, Maximize, RotateCcw, Film, Image as ImageIcon, Columns, Heart, Share2, Star, MessageSquare, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { useVideoStore } from '@/store/video-store';
import { downloadVideo, formatDuration } from '@/lib/video-utils';
import { createFallbackPrompt } from '@/lib/prompt-enhancer';
import { toast } from 'sonner';

// Rating component
function StarRating({ rating, onRate }: { rating: number; onRate: (r: number) => void }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Button
          key={star}
          variant="ghost"
          size="icon"
          className="h-6 w-6 p-0"
          onClick={() => onRate(star)}
        >
          <Star
            className={`h-4 w-4 ${
              star <= rating 
                ? 'fill-yellow-500 text-yellow-500' 
                : 'text-muted-foreground'
            }`}
          />
        </Button>
      ))}
    </div>
  );
}

export function VideoOutput() {
  const { 
    currentTask, 
    uploadedImage,
    toggleFavorite,
    history,
    positivePrompt,
    setPositivePrompt,
  } = useVideoStore();

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [viewMode, setViewMode] = useState<'comparison' | 'video'>('comparison');
  const [rating, setRating] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState('');
  
  const videoRef = useRef<HTMLVideoElement>(null);

  const videoUrl = currentTask?.videoUrl;

  // Video event handlers
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => setCurrentTime(video.currentTime);
    const handleDurationChange = () => setDuration(video.duration);
    const handleEnded = () => setIsPlaying(false);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('durationchange', handleDurationChange);
    video.addEventListener('ended', handleEnded);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('durationchange', handleDurationChange);
      video.removeEventListener('ended', handleEnded);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
    };
  }, [videoUrl]);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
  }, [isPlaying]);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !isMuted;
    setIsMuted(!isMuted);
  }, [isMuted]);

  const handleVolumeChange = useCallback((value: number[]) => {
    const video = videoRef.current;
    if (!video) return;

    const newVolume = value[0];
    video.volume = newVolume;
    setVolume(newVolume);
    setIsMuted(newVolume === 0);
  }, []);

  const handleSeek = useCallback((value: number[]) => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = value[0];
    setCurrentTime(value[0]);
  }, []);

  const handleDownload = useCallback(async () => {
    if (!videoUrl) return;
    
    const filename = `video-${Date.now()}.mp4`;
    toast.promise(downloadVideo(videoUrl, filename), {
      loading: 'Downloading video...',
      success: 'Video downloaded successfully!',
      error: 'Failed to download video',
    });
  }, [videoUrl]);

  const handleFullscreen = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      video.requestFullscreen();
    }
  }, []);

  const handleRestart = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = 0;
    video.play();
  }, []);

  const handleToggleFavorite = useCallback(() => {
    if (currentTask?.id) {
      toggleFavorite(currentTask.id);
      toast.success(currentTask.isFavorite ? 'Removed from favorites' : 'Added to favorites');
    }
  }, [currentTask, toggleFavorite]);

  const handleShare = useCallback(async () => {
    if (!videoUrl) return;

    try {
      await navigator.clipboard.writeText(videoUrl);
      toast.success('Video URL copied to clipboard');
    } catch {
      toast.error('Failed to copy URL');
    }
  }, [videoUrl]);

  // Handle rating
  const handleRate = useCallback((r: number) => {
    setRating(r);
    if (r <= 2) {
      setShowFeedback(true);
    }
    toast.success(`Rated ${r} stars`);
    
    // Store rating for learning (could be sent to backend)
    console.log(`Video rated: ${r}/5 stars`);
  }, []);

  // Handle regenerate with stronger prompt
  const handleRegenerateFallback = useCallback(() => {
    if (!positivePrompt) return;
    
    const fallback = createFallbackPrompt(positivePrompt);
    setPositivePrompt(fallback);
    toast.info('Prompt enhanced. Click Generate to try again.');
  }, [positivePrompt, setPositivePrompt]);

  // Check if task is in history (for favorite state)
  const historyItem = history.find(h => h.id === currentTask?.id);
  const isFavorite = historyItem?.isFavorite ?? false;

  if (!videoUrl) {
    return (
      <Card className="h-full">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Film className="h-4 w-4 text-primary" />
            Generated Video
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center min-h-[300px] text-center p-8 rounded-lg bg-muted/30 border-2 border-dashed">
            <div className="p-4 rounded-full bg-muted mb-4">
              <Film className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground mb-2">No video generated yet</p>
            <p className="text-xs text-muted-foreground/70">
              Upload an image and click Generate to create a video
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Film className="h-4 w-4 text-primary" />
            Generated Video
          </CardTitle>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggleFavorite}
              className={isFavorite ? 'text-red-500' : ''}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleShare}>
              <Share2 className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* View Mode Toggle */}
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'comparison' | 'video')}>
          <TabsList className="w-full">
            <TabsTrigger value="comparison" className="flex-1">
              <Columns className="h-3.5 w-3.5 mr-1.5" />
              Comparison
            </TabsTrigger>
            <TabsTrigger value="video" className="flex-1">
              <Film className="h-3.5 w-3.5 mr-1.5" />
              Video Only
            </TabsTrigger>
          </TabsList>

          {/* Comparison View */}
          <TabsContent value="comparison" className="mt-4">
            <div className="grid grid-cols-2 gap-2">
              {/* Original Image */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ImageIcon className="h-3 w-3" />
                  Original
                </div>
                <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                  {uploadedImage && (
                    <img
                      src={uploadedImage}
                      alt="Original"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
              </div>

              {/* Generated Video */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Film className="h-3 w-3" />
                  Generated
                </div>
                <div className="aspect-video rounded-lg overflow-hidden bg-black relative">
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    className="w-full h-full object-contain"
                    onClick={togglePlay}
                    playsInline
                  />
                  {!isPlaying && (
                    <div 
                      className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
                      onClick={togglePlay}
                    >
                      <div className="p-3 rounded-full bg-white/20 backdrop-blur-sm">
                        <Play className="h-6 w-6 text-white" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Video Only View */}
          <TabsContent value="video" className="mt-4">
            <div className="aspect-video rounded-lg overflow-hidden bg-black relative">
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onClick={togglePlay}
                playsInline
              />
              {!isPlaying && (
                <div 
                  className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
                  onClick={togglePlay}
                >
                  <div className="p-4 rounded-full bg-white/20 backdrop-blur-sm">
                    <Play className="h-8 w-8 text-white" />
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Video Controls */}
        <div className="space-y-3">
          {/* Progress Bar */}
          <div className="space-y-1.5">
            <Slider
              value={[currentTime]}
              min={0}
              max={duration || 100}
              step={0.1}
              onValueChange={handleSeek}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{formatDuration(Math.floor(currentTime))}</span>
              <span>{formatDuration(Math.floor(duration))}</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" onClick={togglePlay}>
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button variant="outline" size="icon" onClick={handleRestart}>
                <RotateCcw className="h-4 w-4" />
              </Button>

              {/* Volume */}
              <div className="flex items-center gap-1 ml-2">
                <Button variant="ghost" size="icon" onClick={toggleMute}>
                  {isMuted || volume === 0 ? (
                    <VolumeX className="h-4 w-4" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </Button>
                <Slider
                  value={[isMuted ? 0 : volume]}
                  min={0}
                  max={1}
                  step={0.1}
                  onValueChange={handleVolumeChange}
                  className="w-20"
                />
              </div>
            </div>

            <Button variant="outline" size="icon" onClick={handleFullscreen}>
              <Maximize className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Video Info */}
        {currentTask && (
          <div className="flex flex-wrap gap-1.5 pt-2 border-t">
            <Badge variant="secondary" className="text-xs">
              {currentTask.settings.duration}s
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {currentTask.settings.fps}fps
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {currentTask.settings.resolution}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {currentTask.settings.quality}
            </Badge>
          </div>
        )}

        {/* Rating Section */}
        <div className="pt-3 border-t space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">How well did it match your prompt?</span>
            <StarRating rating={rating} onRate={handleRate} />
          </div>
          
          {/* Low rating feedback */}
          {showFeedback && rating > 0 && rating <= 2 && (
            <div className="space-y-2 p-3 rounded bg-orange-500/10 border border-orange-500/20">
              <p className="text-xs text-orange-600 dark:text-orange-400">
                Sorry it didn't match well. Try regenerating with a stronger prompt?
              </p>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleRegenerateFallback}
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Regenerate with Stronger Prompt
                </Button>
              </div>
            </div>
          )}
          
          {/* Prompt comparison */}
          {currentTask && (
            <div className="p-2 rounded bg-muted/50 text-xs space-y-1">
              <p className="font-medium">Your prompt:</p>
              <p className="text-muted-foreground line-clamp-2">{currentTask.positivePrompt}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
