'use client';

import { useMemo, useState, useCallback } from 'react';
import { Sparkles, AlertTriangle, CheckCircle, Info, Zap, RefreshCw, Copy, Check } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useVideoStore } from '@/store/video-store';
import { 
  enhancePrompt, 
  enhanceNegativePrompt, 
  analyzePromptQuality,
  createFallbackPrompt,
  generatePromptVariations 
} from '@/lib/prompt-enhancer';

interface PromptDebuggerProps {
  onRegenerateWithFallback?: () => void;
  showResult?: boolean;
  apiResponse?: {
    promptSent?: string;
    negativeSent?: string;
    success?: boolean;
  };
}

export function PromptDebugger({ 
  onRegenerateWithFallback, 
  showResult = false,
  apiResponse 
}: PromptDebuggerProps) {
  const { positivePrompt, negativePrompt, settings } = useVideoStore();
  const [copied, setCopied] = useState(false);
  const [showVariations, setShowVariations] = useState(false);

  // Analyze prompt quality
  const quality = useMemo(() => {
    return analyzePromptQuality(positivePrompt);
  }, [positivePrompt]);

  // Enhance prompts
  const enhancement = useMemo(() => {
    return enhancePrompt(positivePrompt, {
      duration: settings.duration,
      addCameraStability: true,
      addMotionTerms: true,
      useWeights: true,
    });
  }, [positivePrompt, settings.duration]);

  // Enhance negative prompt
  const negativeEnhancement = useMemo(() => {
    return enhanceNegativePrompt(negativePrompt);
  }, [negativePrompt]);

  // Generate variations
  const variations = useMemo(() => {
    return generatePromptVariations(enhancement.enhanced, 3);
  }, [enhancement.enhanced]);

  const handleCopy = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  }, []);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Prompt Analysis
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Score:</span>
            <Badge 
              variant={quality.score >= 80 ? 'default' : quality.score >= 60 ? 'secondary' : 'destructive'}
            >
              {quality.score}%
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quality Score */}
        <div className="space-y-2">
          <Progress value={quality.score} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Prompt Quality</span>
            <span className={getScoreColor(quality.score)}>
              {quality.score >= 80 ? 'Excellent' : quality.score >= 60 ? 'Good' : 'Needs Work'}
            </span>
          </div>
        </div>

        {/* Strengths */}
        {quality.strengths.length > 0 && (
          <div className="space-y-1">
            {quality.strengths.map((strength, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-green-600 dark:text-green-400">
                <CheckCircle className="h-3 w-3" />
                <span>{strength}</span>
              </div>
            ))}
          </div>
        )}

        {/* Issues */}
        {quality.issues.length > 0 && (
          <Alert variant="warning" className="py-2">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <ul className="text-xs space-y-1">
                {quality.issues.map((issue, i) => (
                  <li key={i}>• {issue}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        <Separator />

        {/* Original vs Enhanced */}
        <div className="space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground">Your Original Prompt:</span>
              <Badge variant="outline" className="text-xs">
                {positivePrompt.length} chars
              </Badge>
            </div>
            <div className="p-2 rounded bg-muted/50 text-xs font-mono max-h-[60px] overflow-y-auto">
              {positivePrompt || <span className="text-muted-foreground italic">Empty</span>}
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground">Enhanced for API:</span>
              <div className="flex items-center gap-1">
                <Badge variant="secondary" className="text-xs">
                  +{enhancement.enhanced.length - positivePrompt.length} chars
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  onClick={() => handleCopy(enhancement.enhanced)}
                >
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                </Button>
              </div>
            </div>
            <div className="p-2 rounded bg-primary/10 border border-primary/20 text-xs font-mono max-h-[100px] overflow-y-auto">
              {enhancement.enhanced}
            </div>
          </div>
        </div>

        {/* Motion Expansions */}
        {enhancement.expansions.length > 0 && (
          <div className="space-y-1.5">
            <span className="text-xs font-medium text-muted-foreground">Auto-Expansions Applied:</span>
            <div className="space-y-1">
              {enhancement.expansions.map((exp, i) => (
                <div key={i} className="flex items-center gap-2 text-xs p-1.5 rounded bg-muted/30">
                  <Zap className="h-3 w-3 text-yellow-500" />
                  <span className="font-mono">{exp}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Negative Prompt Info */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-muted-foreground">Negative Prompt:</span>
            <Badge variant="outline" className="text-xs">
              {negativePrompt.length} chars
            </Badge>
          </div>
          <div className="p-2 rounded bg-red-500/10 border border-red-500/20 text-xs font-mono max-h-[80px] overflow-y-auto">
            {negativePrompt.substring(0, 500)}
            {negativePrompt.length > 500 && <span className="text-muted-foreground">... ({negativePrompt.length - 500} more chars)</span>}
          </div>
          {negativeEnhancement.additions.length > 0 && (
            <p className="text-xs text-muted-foreground">
              + Added: {negativeEnhancement.additions.join(', ')}
            </p>
          )}
        </div>

        {/* API Result (after generation) */}
        {showResult && apiResponse && (
          <>
            <Separator />
            <Alert variant={apiResponse.success ? 'default' : 'destructive'} className="py-2">
              {apiResponse.success ? (
                <CheckCircle className="h-4 w-4" />
              ) : (
                <AlertTriangle className="h-4 w-4" />
              )}
              <AlertTitle className="text-sm">
                {apiResponse.success ? 'Prompt Accepted by API' : 'API Response Issue'}
              </AlertTitle>
              <AlertDescription className="text-xs space-y-2">
                {apiResponse.promptSent && (
                  <div>
                    <span className="font-medium">Sent: </span>
                    <span className="font-mono">{apiResponse.promptSent.substring(0, 200)}...</span>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          </>
        )}

        {/* Variations */}
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-xs"
            onClick={() => setShowVariations(!showVariations)}
          >
            {showVariations ? 'Hide' : 'Show'} Prompt Variations
          </Button>
          
          {showVariations && (
            <div className="space-y-2">
              {variations.map((variation, i) => (
                <div key={i} className="p-2 rounded bg-muted/30 text-xs">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-[10px]">
                      Variation {i + 1}
                    </Badge>
                    <span className="text-muted-foreground">{variation.length} chars</span>
                  </div>
                  <p className="font-mono line-clamp-2">{variation}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Fallback Button */}
        {onRegenerateWithFallback && (
          <Button
            variant="outline"
            className="w-full"
            onClick={onRegenerateWithFallback}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Regenerate with Stronger Prompt
          </Button>
        )}

        {/* Info */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p className="flex items-center gap-1">
            <Info className="h-3 w-3" />
            Your prompt is automatically enhanced for better AI understanding
          </p>
          <p>• Motion terms are added based on video duration</p>
          <p>• Ambiguous terms are expanded with specific details</p>
          <p>• Camera stability terms ensure smooth output</p>
        </div>
      </CardContent>
    </Card>
  );
}
