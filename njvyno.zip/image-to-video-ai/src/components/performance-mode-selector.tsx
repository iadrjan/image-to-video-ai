'use client';

import { useCallback } from 'react';
import { Zap, Scale, Sparkles, Clock, Check } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useVideoStore } from '@/store/video-store';
import { PERFORMANCE_MODES, type PerformanceMode } from '@/lib/image-utils';

interface PerformanceModeSelectorProps {
  value: PerformanceMode;
  onChange: (mode: PerformanceMode) => void;
  disabled?: boolean;
}

export function PerformanceModeSelector({ value, onChange, disabled }: PerformanceModeSelectorProps) {
  const { settings, updateSettings } = useVideoStore();

  const handleModeChange = useCallback((mode: PerformanceMode) => {
    onChange(mode);
    
    // Apply the mode's settings
    const modeSettings = PERFORMANCE_MODES[mode].settings;
    updateSettings({
      quality: modeSettings.quality,
      duration: modeSettings.duration,
      resolution: modeSettings.resolution,
    });
  }, [onChange, updateSettings]);

  const getIcon = (mode: PerformanceMode) => {
    switch (mode) {
      case 'fast':
        return <Zap className="h-5 w-5 text-yellow-500" />;
      case 'balanced':
        return <Scale className="h-5 w-5 text-blue-500" />;
      case 'quality':
        return <Sparkles className="h-5 w-5 text-purple-500" />;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          Performance Mode
        </CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={value}
          onValueChange={(v) => handleModeChange(v as PerformanceMode)}
          disabled={disabled}
          className="grid grid-cols-1 gap-3"
        >
          {Object.entries(PERFORMANCE_MODES).map(([key, mode]) => (
            <div key={key}>
              <RadioGroupItem
                value={key}
                id={`mode-${key}`}
                className="peer sr-only"
              />
              <Label
                htmlFor={`mode-${key}`}
                className={`
                  flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer
                  transition-all duration-200
                  ${value === key 
                    ? 'border-primary bg-primary/5' 
                    : 'border-muted hover:border-muted-foreground/50 hover:bg-muted/30'
                  }
                  ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
                `}
              >
                <div className="flex-shrink-0">
                  {getIcon(key as PerformanceMode)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{mode.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {mode.description}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    <Badge variant="outline" className="text-[10px]">
                      {mode.settings.duration}s
                    </Badge>
                    <Badge variant="outline" className="text-[10px]">
                      {mode.settings.resolution}
                    </Badge>
                    <Badge variant="outline" className="text-[10px]">
                      {mode.settings.quality}
                    </Badge>
                  </div>
                </div>

                {value === key && (
                  <Check className="h-5 w-5 text-primary flex-shrink-0" />
                )}
              </Label>
            </div>
          ))}
        </RadioGroup>

        <div className="mt-3 p-2 rounded bg-muted/50 text-xs text-muted-foreground">
          <p className="font-medium mb-1">Mode affects:</p>
          <ul className="space-y-0.5">
            <li>• <strong>Fast</strong>: Speed quality, 5s video, 720p</li>
            <li>• <strong>Balanced</strong>: Quality mode, 5s video, 1080p</li>
            <li>• <strong>Best Quality</strong>: Quality mode, 10s video, 1080p</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
