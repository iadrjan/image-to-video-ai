'use client';

import { useCallback, useState, useRef } from 'react';
import { Upload, X, ZoomIn, ZoomOut, Crop, RotateCcw, ImageIcon, Check, AlertCircle, RefreshCw, Eye, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useVideoStore } from '@/store/video-store';
import { processImageForApi, validateImage, formatBytes, type ImageProcessingResult } from '@/lib/image-utils';
import { toast } from 'sonner';

export function ImageUpload() {
  const { uploadedImage, imageDimensions, setImage, clearImage } = useVideoStore();
  const [isDragging, setIsDragging] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [showCropModal, setShowCropModal] = useState(false);
  const [cropArea, setCropArea] = useState({ x: 0, y: 0, width: 100, height: 100 });
  const [isProcessing, setIsProcessing] = useState(false);
  const [showOriginal, setShowOriginal] = useState(false);
  const [processingResult, setProcessingResult] = useState<ImageProcessingResult | null>(null);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [imageInfo, setImageInfo] = useState<{
    format: string;
    size: number;
    dimensions: { width: number; height: number };
  } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  // Handle any file - we accept ALL images
  const handleFile = useCallback(async (file: File) => {
    setIsProcessing(true);
    
    try {
      // Store original
      const originalBase64 = await processImageForApi(file, { 
        maxDimension: 8000, // Keep original size for preview
        quality: 1.0,
        targetSizeKB: 10000,
      });
      setOriginalImage(originalBase64.optimized);
      
      // Validate (always returns valid = true)
      const validation = await validateImage(file);
      setImageInfo({
        format: validation.format,
        size: validation.size,
        dimensions: validation.dimensions,
      });
      
      // Process for API
      const result = await processImageForApi(file);
      setProcessingResult(result);
      
      // Set the processed image
      setImage(result.optimized, { 
        width: result.outputWidth, 
        height: result.outputHeight 
      });
      setZoom(1);
      
      // Show success message with changes
      if (result.changes.length > 0) {
        toast.success('Image processed', {
          description: result.changes.join(' • '),
        });
      } else {
        toast.success('Image uploaded successfully');
      }
      
    } catch (error: any) {
      console.error('Image processing error:', error);
      toast.error('Could not process image', {
        description: 'Please try a different image',
      });
    } finally {
      setIsProcessing(false);
    }
  }, [setImage]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      handleFile(file);
    }
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  }, [handleFile]);

  const handleClearImage = useCallback(() => {
    clearImage();
    setOriginalImage(null);
    setProcessingResult(null);
    setImageInfo(null);
    setZoom(1);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [clearImage]);

  const handleZoomIn = useCallback(() => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  }, []);

  const handleResetZoom = useCallback(() => {
    setZoom(1);
  }, []);

  const handleCrop = useCallback(() => {
    if (!uploadedImage || !imageRef.current) return;
    setShowCropModal(true);
    
    const img = imageRef.current;
    const minDim = Math.min(img.naturalWidth, img.naturalHeight);
    setCropArea({
      x: (img.naturalWidth - minDim) / 2,
      y: (img.naturalHeight - minDim) / 2,
      width: minDim,
      height: minDim,
    });
  }, [uploadedImage]);

  const applyCrop = useCallback(async () => {
    if (!uploadedImage) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = async () => {
      canvas.width = cropArea.width;
      canvas.height = cropArea.height;
      
      ctx.drawImage(
        img,
        cropArea.x,
        cropArea.y,
        cropArea.width,
        cropArea.height,
        0,
        0,
        cropArea.width,
        cropArea.height
      );

      const croppedBase64 = canvas.toDataURL('image/jpeg', 0.92);
      
      // Update processing result
      setProcessingResult(prev => prev ? {
        ...prev,
        outputWidth: cropArea.width,
        outputHeight: cropArea.height,
        changes: [...prev.changes, `Cropped to ${cropArea.width}×${cropArea.height}`],
      } : null);
      
      setImage(croppedBase64, { width: cropArea.width, height: cropArea.height });
      setShowCropModal(false);
      toast.success('Image cropped');
    };
    img.src = uploadedImage;
  }, [uploadedImage, cropArea, setImage]);

  // Format display name helper
  const getFormatDisplay = (format: string) => {
    return format.replace('image/', '').toUpperCase();
  };

  if (!uploadedImage) {
    return (
      <Card className="h-full">
        <CardContent className="h-full p-0">
          <div
            className={`
              relative h-full min-h-[400px] flex flex-col items-center justify-center
              border-2 border-dashed rounded-lg transition-all duration-200 cursor-pointer
              ${isDragging 
                ? 'border-primary bg-primary/10 scale-[1.02]' 
                : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/50'
              }
              ${isProcessing ? 'pointer-events-none opacity-50' : ''}
            `}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => !isProcessing && fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileInput}
              className="hidden"
            />
            
            {isProcessing ? (
              <div className="flex flex-col items-center gap-4 p-8">
                <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                <p className="text-lg font-medium">Processing image...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4 p-8">
                <div className={`
                  p-4 rounded-full transition-colors
                  ${isDragging ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}
                `}>
                  <Upload className="h-8 w-8" />
                </div>
                
                <div className="text-center">
                  <p className="text-lg font-medium">
                    {isDragging ? 'Drop image here' : 'Drag & drop any image'}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    or click to browse
                  </p>
                </div>
                
                <div className="flex flex-wrap justify-center gap-2 text-xs text-muted-foreground">
                  <span className="px-2 py-1 bg-muted rounded">JPG</span>
                  <span className="px-2 py-1 bg-muted rounded">PNG</span>
                  <span className="px-2 py-1 bg-muted rounded">WEBP</span>
                  <span className="px-2 py-1 bg-muted rounded">GIF</span>
                  <span className="px-2 py-1 bg-muted rounded">BMP</span>
                  <span className="px-2 py-1 bg-muted rounded">TIFF</span>
                  <span className="px-2 py-1 bg-muted rounded">HEIC</span>
                  <span className="px-2 py-1 bg-muted rounded">Up to 50MB</span>
                </div>
                
                <p className="text-xs text-muted-foreground text-center max-w-sm">
                  All formats accepted • Auto-conversion • No rejections
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="h-full">
        <CardContent className="h-full p-4 flex flex-col">
          {/* Toolbar */}
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleZoomOut}
                disabled={zoom <= 0.5}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium min-w-[3rem] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={handleZoomIn}
                disabled={zoom >= 3}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleResetZoom}
                disabled={zoom === 1}
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleCrop}
              >
                <Crop className="h-4 w-4" />
              </Button>
            </div>
            
            <Button
              variant="destructive"
              size="sm"
              onClick={handleClearImage}
            >
              <X className="h-4 w-4 mr-1" />
              Remove
            </Button>
          </div>

          {/* Image Preview with Toggle */}
          <div className="flex-1 relative overflow-hidden rounded-lg bg-muted/50 flex items-center justify-center">
            <div 
              className="relative overflow-auto max-h-full"
              style={{ 
                transform: `scale(${zoom})`,
                transformOrigin: 'center'
              }}
            >
              <img
                ref={imageRef}
                src={showOriginal && originalImage ? originalImage : uploadedImage}
                alt={showOriginal ? "Original image" : "Processed image"}
                className="max-w-full max-h-full object-contain rounded"
              />
            </div>
            
            {/* Original/Processed Toggle */}
            {originalImage && processingResult?.changes.length ? (
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-center gap-2 p-2 rounded bg-background/80 backdrop-blur-sm">
                <Label className="text-xs">Original</Label>
                <Switch
                  checked={!showOriginal}
                  onCheckedChange={(checked) => setShowOriginal(!checked)}
                />
                <Label className="text-xs">For API</Label>
                {showOriginal ? (
                  <Badge variant="secondary" className="text-xs ml-2">Viewing original</Badge>
                ) : (
                  <Badge variant="default" className="text-xs ml-2">What API receives</Badge>
                )}
              </div>
            ) : null}
          </div>

          {/* Image Info Panel */}
          <div className="mt-3 space-y-2">
            {/* Status Badge */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span className="text-sm font-medium text-green-600 dark:text-green-400">
                  ✓ Image ready for generation
                </span>
              </div>
            </div>
            
            {/* Info Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="p-2 rounded bg-muted/50">
                <p className="text-xs text-muted-foreground">Format</p>
                <p className="text-sm font-medium">
                  {processingResult ? getFormatDisplay(processingResult.outputFormat) : 
                   imageInfo ? getFormatDisplay(imageInfo.format) : 'JPEG'}
                </p>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <p className="text-xs text-muted-foreground">Dimensions</p>
                <p className="text-sm font-medium">
                  {imageDimensions ? `${imageDimensions.width}×${imageDimensions.height}` : '-'}
                </p>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <p className="text-xs text-muted-foreground">File Size</p>
                <p className="text-sm font-medium">
                  {processingResult ? formatBytes(processingResult.outputSize) :
                   imageInfo ? formatBytes(imageInfo.size) : '-'}
                </p>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <p className="text-xs text-muted-foreground">Status</p>
                <p className="text-sm font-medium text-green-600 dark:text-green-400">
                  ✓ Ready
                </p>
              </div>
            </div>

            {/* Changes Applied */}
            {processingResult && processingResult.changes.length > 0 && (
              <Alert className="bg-blue-500/10 border-blue-500/20">
                <AlertCircle className="h-4 w-4 text-blue-500" />
                <AlertDescription className="text-xs">
                  <span className="font-medium">Auto-applied: </span>
                  {processingResult.changes.join(' • ')}
                </AlertDescription>
              </Alert>
            )}
            
            {/* Original vs Processed */}
            {processingResult && (processingResult.wasResized || processingResult.wasConverted || processingResult.wasCompressed) && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>Original: {processingResult.originalWidth}×{processingResult.originalHeight} {getFormatDisplay(processingResult.originalFormat)} {formatBytes(processingResult.originalSize)}</span>
                <ArrowRight className="h-3 w-3" />
                <span>Processed: {processingResult.outputWidth}×{processingResult.outputHeight} JPEG {formatBytes(processingResult.outputSize)}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Crop Modal */}
      <Dialog open={showCropModal} onOpenChange={setShowCropModal}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Crop Image</DialogTitle>
          </DialogHeader>
          
          <div className="relative bg-muted rounded-lg overflow-hidden">
            <img
              src={uploadedImage}
              alt="Crop preview"
              className="max-w-full max-h-[400px] mx-auto"
            />
            <div 
              className="absolute border-2 border-primary bg-primary/10"
              style={{
                left: `${(cropArea.x / (imageDimensions?.width || 1)) * 100}%`,
                top: `${(cropArea.y / (imageDimensions?.height || 1)) * 100}%`,
                width: `${(cropArea.width / (imageDimensions?.width || 1)) * 100}%`,
                height: `${(cropArea.height / (imageDimensions?.height || 1)) * 100}%`,
              }}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">X Position</label>
              <Slider
                value={[cropArea.x]}
                min={0}
                max={(imageDimensions?.width || 100) - cropArea.width}
                step={1}
                onValueChange={([x]) => setCropArea(prev => ({ ...prev, x }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Y Position</label>
              <Slider
                value={[cropArea.y]}
                min={0}
                max={(imageDimensions?.height || 100) - cropArea.height}
                step={1}
                onValueChange={([y]) => setCropArea(prev => ({ ...prev, y }))}
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium">Size</label>
              <Slider
                value={[cropArea.width]}
                min={50}
                max={Math.min(imageDimensions?.width || 100, imageDimensions?.height || 100)}
                step={1}
                onValueChange={([width]) => setCropArea(prev => ({ ...prev, width, height: width }))}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCropModal(false)}>
              Cancel
            </Button>
            <Button onClick={applyCrop}>
              Apply Crop
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
