'use client';

import { useCallback, useState } from 'react';
import { Settings, RotateCcw, Zap, Clock, Monitor, Gauge, Hash, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useVideoStore } from '@/store/video-store';
import { VIDEO_RESOLUTIONS, DEFAULT_SETTINGS } from '@/types/video';

export function GenerationSettings() {
  const { settings, updateSettings, resetSettings } = useVideoStore();
  const [fpsOpen, setFpsOpen] = useState(false);
  const [resOpen, setResOpen] = useState(false);

  const handleDurationChange = useCallback((value: string) => {
    updateSettings({ duration: parseInt(value) as 5 | 10 });
  }, [updateSettings]);

  const handleFpsChange = useCallback((value: string) => {
    updateSettings({ fps: parseInt(value) as 30 | 60 });
    setFpsOpen(false);
  }, [updateSettings]);

  const handleResolutionChange = useCallback((value: string) => {
    updateSettings({ resolution: value });
    setResOpen(false);
  }, [updateSettings]);

  const handleQualityChange = useCallback((checked: boolean) => {
    updateSettings({ quality: checked ? 'quality' : 'speed' });
  }, [updateSettings]);

  const handleMotionChange = useCallback((value: number[]) => {
    updateSettings({ motionIntensity: value[0] });
  }, [updateSettings]);

  const handleSeedChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '') {
      updateSettings({ seed: null });
    } else {
      const num = parseInt(value);
      if (!isNaN(num) && num >= 0) {
        updateSettings({ seed: num });
      }
    }
  }, [updateSettings]);

  const getMotionLabel = (value: number): string => {
    if (value <= 2) return 'Subtle';
    if (value <= 4) return 'Gentle';
    if (value <= 6) return 'Moderate';
    if (value <= 8) return 'Dynamic';
    return 'Intense';
  };

  const stopPropagation = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
  }, []);

  return (
    <Card className="h-full" onClick={stopPropagation}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="h-4 w-4 text-primary" />
            Generation Settings
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              resetSettings();
            }}
            className="h-7 text-xs"
          >
            <RotateCcw className="h-3 w-3 mr-1" />
            Reset
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-5" onClick={stopPropagation}>
        {/* Video Duration */}
        <div className="space-y-2">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Clock className="h-3.5 w-3.5 text-muted-foreground" />
            Video Duration
          </Label>
          <RadioGroup
            value={settings.duration.toString()}
            onValueChange={handleDurationChange}
            className="flex gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="5" id="duration-5" />
              <Label htmlFor="duration-5" className="cursor-pointer">5 seconds</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="10" id="duration-10" />
              <Label htmlFor="duration-10" className="cursor-pointer">10 seconds</Label>
            </div>
          </RadioGroup>
        </div>

        <Separator />

        {/* Frame Rate */}
        <div className="space-y-2">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Monitor className="h-3.5 w-3.5 text-muted-foreground" />
            Frame Rate
          </Label>
          <Select 
            value={settings.fps.toString()} 
            onValueChange={handleFpsChange}
            open={fpsOpen}
            onOpenChange={setFpsOpen}
          >
            <SelectTrigger onClick={(e) => e.stopPropagation()}>
              <SelectValue placeholder="Select frame rate" />
            </SelectTrigger>
            <SelectContent onClick={(e) => e.stopPropagation()}>
              <SelectItem value="30">30 FPS (Standard)</SelectItem>
              <SelectItem value="60">60 FPS (Smooth)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Resolution */}
        <div className="space-y-2">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Monitor className="h-3.5 w-3.5 text-muted-foreground" />
            Resolution
          </Label>
          <Select 
            value={settings.resolution} 
            onValueChange={handleResolutionChange}
            open={resOpen}
            onOpenChange={setResOpen}
          >
            <SelectTrigger onClick={(e) => e.stopPropagation()}>
              <SelectValue placeholder="Select resolution" />
            </SelectTrigger>
            <SelectContent onClick={(e) => e.stopPropagation()}>
              {VIDEO_RESOLUTIONS.map((res) => (
                <SelectItem key={res.value} value={res.value}>
                  {res.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Quality Mode */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-muted-foreground" />
              Quality Mode
            </Label>
            <p className="text-xs text-muted-foreground">
              {settings.quality === 'quality' 
                ? 'Higher quality, slower generation' 
                : 'Faster generation, good quality'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={settings.quality === 'speed' ? 'default' : 'outline'} className="text-xs">
              <Zap className="h-3 w-3 mr-1" />
              Speed
            </Badge>
            <Switch
              checked={settings.quality === 'quality'}
              onCheckedChange={handleQualityChange}
            />
            <Badge variant={settings.quality === 'quality' ? 'default' : 'outline'} className="text-xs">
              <Sparkles className="h-3 w-3 mr-1" />
              Quality
            </Badge>
          </div>
        </div>

        <Separator />

        {/* Motion Intensity */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Gauge className="h-3.5 w-3.5 text-muted-foreground" />
              Motion Intensity
            </Label>
            <Badge variant="secondary" className="text-xs">
              {getMotionLabel(settings.motionIntensity)}
            </Badge>
          </div>
          <Slider
            value={[settings.motionIntensity]}
            min={1}
            max={10}
            step={1}
            onValueChange={handleMotionChange}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Subtle</span>
            <span>Intense</span>
          </div>
        </div>

        <Separator />

        {/* Seed (Advanced) */}
        <div className="space-y-2">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Hash className="h-3.5 w-3.5 text-muted-foreground" />
            Seed (Optional)
          </Label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Random"
              value={settings.seed ?? ''}
              onChange={handleSeedChange}
              min={0}
              className="flex-1"
              onClick={stopPropagation}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                updateSettings({ seed: Math.floor(Math.random() * 2147483647) });
              }}
            >
              Random
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Use same seed for reproducible results
          </p>
        </div>

        {/* Current Settings Summary */}
        <div className="pt-2 border-t">
          <div className="flex flex-wrap gap-1.5">
            <Badge variant="outline" className="text-xs">
              {settings.duration}s
            </Badge>
            <Badge variant="outline" className="text-xs">
              {settings.fps}fps
            </Badge>
            <Badge variant="outline" className="text-xs">
              {settings.resolution}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {settings.quality}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
