'use client';

import { useMemo, useCallback } from 'react';
import { AlertCircle, AlertTriangle, Info, CheckCircle, Sparkles, Shield, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useVideoStore } from '@/store/video-store';
import { 
  analyzePrompts, 
  getSeverityColor, 
  getSeverityVariant,
  type PromptWarning 
} from '@/lib/prompt-utils';

interface PromptHealthCheckProps {
  onPreviewRequest?: () => void;
}

export function PromptHealthCheck({ onPreviewRequest }: PromptHealthCheckProps) {
  const { positivePrompt, negativePrompt } = useVideoStore();

  const analysis = useMemo(() => {
    return analyzePrompts(positivePrompt, negativePrompt);
  }, [positivePrompt, negativePrompt]);

  const getWarningIcon = (severity: PromptWarning['severity']) => {
    switch (severity) {
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'info':
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  const healthScore = useMemo(() => {
    let score = 100;
    
    // Deduct for errors
    const errors = analysis.warnings.filter(w => w.severity === 'error').length;
    score -= errors * 30;
    
    // Deduct for warnings
    const warnings = analysis.warnings.filter(w => w.severity === 'warning').length;
    score -= warnings * 10;
    
    // Deduct for info
    const infos = analysis.warnings.filter(w => w.severity === 'info').length;
    score -= infos * 2;
    
    return Math.max(0, Math.min(100, score));
  }, [analysis.warnings]);

  const healthColor = useMemo(() => {
    if (healthScore >= 80) return 'text-green-500';
    if (healthScore >= 50) return 'text-yellow-500';
    return 'text-red-500';
  }, [healthScore]);

  if (analysis.warnings.length === 0 && positivePrompt.length > 0) {
    return (
      <Card className="border-green-500/30 bg-green-500/5">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <div>
              <p className="font-medium text-green-600 dark:text-green-400">Prompts look good!</p>
              <p className="text-xs text-muted-foreground">
                {analysis.positiveLength.toLocaleString()} chars positive • {analysis.negativeLength.toLocaleString()} chars negative
              </p>
            </div>
            {onPreviewRequest && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={onPreviewRequest}
                className="ml-auto"
              >
                Preview API Request
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            Prompt Health Check
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Score:</span>
            <Badge variant={healthScore >= 80 ? 'default' : healthScore >= 50 ? 'secondary' : 'destructive'}>
              {healthScore}%
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded bg-muted/50">
            <p className="text-lg font-bold">{analysis.positiveLength.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Positive chars</p>
          </div>
          <div className="p-2 rounded bg-muted/50">
            <p className="text-lg font-bold">{analysis.negativeLength.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Negative chars</p>
          </div>
          <div className="p-2 rounded bg-muted/50">
            <p className="text-lg font-bold">{analysis.estimatedTokens.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Est. tokens</p>
          </div>
        </div>

        {/* Warnings */}
        {analysis.warnings.length > 0 && (
          <ScrollArea className="max-h-[200px]">
            <div className="space-y-2">
              {analysis.warnings.map((warning, index) => (
                <Alert key={index} variant={warning.severity === 'error' ? 'destructive' : 'default'}>
                  {getWarningIcon(warning.severity)}
                  <AlertTitle className="text-sm">{warning.message}</AlertTitle>
                  {warning.details && (
                    <AlertDescription className="text-xs">
                      {warning.details}
                    </AlertDescription>
                  )}
                </Alert>
              ))}
            </div>
          </ScrollArea>
        )}

        {/* Suggestions */}
        {analysis.suggestions.length > 0 && (
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground">Suggestions:</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              {analysis.suggestions.slice(0, 3).map((suggestion, index) => (
                <li key={index} className="flex items-start gap-1.5">
                  <Zap className="h-3 w-3 mt-0.5 text-yellow-500 flex-shrink-0" />
                  <span>{suggestion}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Filtered Terms */}
        {analysis.filteredTerms.length > 0 && (
          <div className="p-2 rounded bg-blue-500/10 border border-blue-500/20">
            <p className="text-xs font-medium text-blue-600 dark:text-blue-400 mb-1">
              Potentially filtered terms (in negative prompt):
            </p>
            <div className="flex flex-wrap gap-1">
              {analysis.filteredTerms.map((term, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {term}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              These are for PREVENTION (to avoid unwanted content) and should be accepted.
            </p>
          </div>
        )}

        {/* Contradictions */}
        {analysis.contradictoryTerms.length > 0 && (
          <div className="p-2 rounded bg-yellow-500/10 border border-yellow-500/20">
            <p className="text-xs font-medium text-yellow-600 dark:text-yellow-400 mb-1">
              Contradictory terms found in both prompts:
            </p>
            <div className="flex flex-wrap gap-1">
              {analysis.contradictoryTerms.slice(0, 10).map((term, index) => (
                <Badge key={index} variant="outline" className="text-xs border-yellow-500/50">
                  {term}
                </Badge>
              ))}
              {analysis.contradictoryTerms.length > 10 && (
                <Badge variant="outline" className="text-xs">
                  +{analysis.contradictoryTerms.length - 10} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Preview Button */}
        {onPreviewRequest && (
          <Button 
            variant="outline" 
            className="w-full"
            onClick={onPreviewRequest}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Preview API Request
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
