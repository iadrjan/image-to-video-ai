'use client';

import { useCallback, useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Sparkles, FileText, Lightbulb, TestTube, Wand2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useVideoStore } from '@/store/video-store';
import { PROMPT_TEMPLATES, DEFAULT_NEGATIVE_PROMPT } from '@/types/video';
import { enhancePrompt, analyzePromptQuality } from '@/lib/prompt-enhancer';
import { PromptDebugger } from '@/components/prompt-debugger';

export function PromptSection() {
  const { 
    positivePrompt, 
    negativePrompt, 
    setPositivePrompt, 
    setNegativePrompt,
    settings,
  } = useVideoStore();
  
  const [localPositive, setLocalPositive] = useState(positivePrompt);
  const [localNegative, setLocalNegative] = useState(negativePrompt);
  const [isNegativeOpen, setIsNegativeOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [showTestDialog, setShowTestDialog] = useState(false);

  // Sync local state with store on mount and when store changes
  useEffect(() => {
    setLocalPositive(positivePrompt);
  }, [positivePrompt]);

  useEffect(() => {
    setLocalNegative(negativePrompt);
  }, [negativePrompt]);

  // Handle positive prompt change - NO CHARACTER LIMIT
  const handlePositiveChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setLocalPositive(value);
    setPositivePrompt(value);
  }, [setPositivePrompt]);

  // Handle negative prompt change - NO CHARACTER LIMIT
  const handleNegativeChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setLocalNegative(value);
    setNegativePrompt(value);
  }, [setNegativePrompt]);

  // Handle template selection
  const handleTemplateSelect = useCallback((prompt: string) => {
    setLocalPositive(prompt);
    setPositivePrompt(prompt);
    setTemplatesOpen(false);
  }, [setPositivePrompt]);

  // Reset negative prompt to default
  const handleResetNegative = useCallback(() => {
    setLocalNegative(DEFAULT_NEGATIVE_PROMPT);
    setNegativePrompt(DEFAULT_NEGATIVE_PROMPT);
  }, [setNegativePrompt]);

  // Prevent event bubling for textareas
  const stopPropagation = useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
    e.stopPropagation();
  }, []);

  // Quick enhance the prompt
  const handleQuickEnhance = useCallback(() => {
    const enhanced = enhancePrompt(localPositive, {
      duration: settings.duration,
      addCameraStability: true,
      addMotionTerms: true,
      useWeights: false,
    });
    setLocalPositive(enhanced.enhanced);
    setPositivePrompt(enhanced.enhanced);
  }, [localPositive, settings.duration, setPositivePrompt]);

  return (
    <>
      <Card onClick={stopPropagation}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              Prompts
            </CardTitle>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowTestDialog(true)}
                className="h-7 text-xs gap-1"
              >
                <TestTube className="h-3 w-3" />
                Test
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleQuickEnhance}
                className="h-7 text-xs gap-1"
              >
                <Wand2 className="h-3 w-3" />
                Enhance
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4" onClick={stopPropagation}>
          {/* Positive Prompt */}
          <div className="space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                Positive Prompt
              </label>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {localPositive.length.toLocaleString()} chars
                </Badge>
                <DropdownMenu open={templatesOpen} onOpenChange={setTemplatesOpen}>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-7 gap-1"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Lightbulb className="h-3.5 w-3.5" />
                      Templates
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent 
                    align="end" 
                    className="w-72"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {PROMPT_TEMPLATES.map((template, index) => (
                      <DropdownMenuItem
                        key={index}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleTemplateSelect(template.prompt);
                        }}
                        className="cursor-pointer"
                      >
                        <div className="py-1">
                          <div className="font-medium">{template.name}</div>
                          <div className="text-xs text-muted-foreground line-clamp-2">
                            {template.prompt}
                          </div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
            <Textarea
              value={localPositive}
              onChange={handlePositiveChange}
              onClick={stopPropagation}
              placeholder="Describe the motion you want... (e.g., 'woman smiling at camera, natural smile forming, eyes crinkling with joy')"
              className="min-h-[120px] resize-y"
              style={{ pointerEvents: 'auto' }}
            />
            <p className="text-xs text-muted-foreground">
              Be specific about motion. Auto-enhanced for better results.
            </p>
          </div>

          {/* Negative Prompt */}
          <Collapsible open={isNegativeOpen} onOpenChange={setIsNegativeOpen}>
            <CollapsibleTrigger asChild>
              <Button
                variant="ghost"
                className="w-full justify-between p-2 h-auto"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsNegativeOpen(!isNegativeOpen);
                }}
              >
                <span className="text-sm font-medium flex items-center gap-2">
                  <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                  Negative Prompt
                  <Badge variant="secondary" className="text-xs">
                    {localNegative.length.toLocaleString()} chars
                  </Badge>
                </span>
                {isNegativeOpen ? (
                  <ChevronUp className="h-4 w-4" />
                ) : (
                  <ChevronDown className="h-4 w-4" />
                )}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2 pt-2">
              <Textarea
                value={localNegative}
                onChange={handleNegativeChange}
                onClick={stopPropagation}
                placeholder="Things to avoid in the generated video..."
                className="min-h-[200px] resize-y text-xs font-mono"
                style={{ pointerEvents: 'auto' }}
              />
              <div className="flex items-center justify-between flex-wrap gap-2">
                <p className="text-xs text-muted-foreground">
                  Terms to PREVENT unwanted artifacts
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleResetNegative();
                  }}
                  className="text-xs"
                >
                  Reset to Default
                </Button>
              </div>
            </CollapsibleContent>
          </Collapsible>

          {/* Quick Tips */}
          <div className="text-xs text-muted-foreground border-t pt-3 space-y-1">
            <p className="font-medium">Prompt Tips:</p>
            <ul className="list-disc list-inside space-y-0.5 text-xs">
              <li>Describe specific motions: "head turning slowly left"</li>
              <li>Add timing: "slowly", "gradually", "smoothly"</li>
              <li>Include details: "natural smile", "gentle blink"</li>
              <li>Click "Test" to analyze before generating</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Test Prompt Dialog */}
      <Dialog open={showTestDialog} onOpenChange={setShowTestDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <TestTube className="h-5 w-5" />
              Prompt Analysis & Testing
            </DialogTitle>
            <DialogDescription>
              Analyze your prompt before generation to predict results
            </DialogDescription>
          </DialogHeader>
          
          <PromptDebugger />
        </DialogContent>
      </Dialog>
    </>
  );
}
