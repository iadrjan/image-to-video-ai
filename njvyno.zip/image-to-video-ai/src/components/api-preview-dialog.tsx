'use client';

import { useMemo, useState, useCallback } from 'react';
import { Eye, Copy, Check, AlertTriangle, FileJson, Send, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useVideoStore } from '@/store/video-store';
import { preparePromptsForApi, analyzePrompts } from '@/lib/prompt-utils';

interface ApiPreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

export function ApiPreviewDialog({ open, onOpenChange, onConfirm }: ApiPreviewDialogProps) {
  const { positivePrompt, negativePrompt, settings, uploadedImage } = useVideoStore();
  const [copied, setCopied] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const analysis = useMemo(() => {
    return analyzePrompts(positivePrompt, negativePrompt);
  }, [positivePrompt, negativePrompt]);

  const preparedPrompts = useMemo(() => {
    return preparePromptsForApi(positivePrompt, negativePrompt, {
      motionIntensity: settings.motionIntensity,
    });
  }, [positivePrompt, negativePrompt, settings.motionIntensity]);

  const apiRequest = useMemo(() => {
    return {
      image: uploadedImage ? `[Base64 image - ${Math.round(uploadedImage.length / 1024)}KB]` : null,
      prompt: preparedPrompts.finalPositivePrompt,
      negativePrompt: preparedPrompts.finalNegativePrompt,
      settings: {
        duration: settings.duration,
        fps: settings.fps,
        resolution: settings.resolution,
        quality: settings.quality,
        motionIntensity: settings.motionIntensity,
        seed: settings.seed,
      },
    };
  }, [uploadedImage, preparedPrompts, settings]);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(apiRequest, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  }, [apiRequest]);

  const handleConfirm = useCallback(() => {
    setConfirmed(true);
    onConfirm();
    onOpenChange(false);
  }, [onConfirm, onOpenChange]);

  const promptDiff = useMemo(() => {
    const positiveDiff = preparedPrompts.finalPositivePrompt.length - positivePrompt.length;
    const negativeDiff = preparedPrompts.finalNegativePrompt.length - negativePrompt.length;
    
    return {
      positiveAdded: positiveDiff > 0 ? positiveDiff : 0,
      positiveRemoved: positiveDiff < 0 ? Math.abs(positiveDiff) : 0,
      negativeAdded: negativeDiff > 0 ? negativeDiff : 0,
      negativeRemoved: negativeDiff < 0 ? Math.abs(negativeDiff) : 0,
    };
  }, [preparedPrompts, positivePrompt, negativePrompt]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            API Request Preview
          </DialogTitle>
          <DialogDescription>
            Review exactly what will be sent to the video generation API
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          <Tabs defaultValue="prompts" className="h-full flex flex-col">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="prompts">Prompts</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="json">Full JSON</TabsTrigger>
            </TabsList>

            <div className="flex-1 overflow-hidden mt-4">
              {/* Prompts Tab */}
              <TabsContent value="prompts" className="h-full mt-0">
                <ScrollArea className="h-[400px]">
                  <div className="space-y-4 p-1">
                    {/* Modifications Warning */}
                    {(preparedPrompts.modifications.length > 0 || preparedPrompts.warnings.length > 0) && (
                      <div className="p-3 rounded bg-yellow-500/10 border border-yellow-500/20">
                        <p className="text-sm font-medium text-yellow-600 dark:text-yellow-400 mb-2">
                          <AlertTriangle className="h-4 w-4 inline mr-1" />
                          Modifications Applied
                        </p>
                        {preparedPrompts.modifications.map((mod, i) => (
                          <p key={i} className="text-xs text-muted-foreground">• {mod}</p>
                        ))}
                        {preparedPrompts.warnings.map((warn, i) => (
                          <p key={i} className="text-xs text-yellow-600 dark:text-yellow-400">• {warn}</p>
                        ))}
                      </div>
                    )}

                    {/* Positive Prompt */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium">Positive Prompt</h4>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            {preparedPrompts.finalPositivePrompt.length.toLocaleString()} chars
                          </Badge>
                          {promptDiff.positiveAdded > 0 && (
                            <Badge variant="outline" className="text-green-500 border-green-500/50">
                              +{promptDiff.positiveAdded}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="p-3 rounded bg-muted/50 border font-mono text-xs whitespace-pre-wrap break-all">
                        {preparedPrompts.finalPositivePrompt || <span className="text-muted-foreground italic">Empty</span>}
                      </div>
                    </div>

                    <Separator />

                    {/* Negative Prompt */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium">Negative Prompt</h4>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            {preparedPrompts.finalNegativePrompt.length.toLocaleString()} chars
                          </Badge>
                          {promptDiff.negativeRemoved > 0 && (
                            <Badge variant="outline" className="text-yellow-500 border-yellow-500/50">
                              -{promptDiff.negativeRemoved} condensed
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="p-3 rounded bg-muted/50 border font-mono text-xs whitespace-pre-wrap break-all max-h-[200px] overflow-y-auto">
                        {preparedPrompts.finalNegativePrompt || <span className="text-muted-foreground italic">Empty</span>}
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </TabsContent>

              {/* Settings Tab */}
              <TabsContent value="settings" className="h-full mt-0">
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3 p-1">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Duration</p>
                        <p className="text-lg font-bold">{settings.duration}s</p>
                      </div>
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Frame Rate</p>
                        <p className="text-lg font-bold">{settings.fps} fps</p>
                      </div>
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Resolution</p>
                        <p className="text-lg font-bold">{settings.resolution}</p>
                      </div>
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Quality</p>
                        <p className="text-lg font-bold capitalize">{settings.quality}</p>
                      </div>
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Motion Intensity</p>
                        <p className="text-lg font-bold">{settings.motionIntensity}/10</p>
                      </div>
                      <div className="p-3 rounded bg-muted/50">
                        <p className="text-xs text-muted-foreground">Seed</p>
                        <p className="text-lg font-bold">{settings.seed ?? 'Random'}</p>
                      </div>
                    </div>

                    <Separator />

                    <div className="p-3 rounded bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">Image</p>
                      {uploadedImage ? (
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-16 rounded overflow-hidden bg-muted">
                            <img 
                              src={uploadedImage} 
                              alt="Preview" 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Base64 encoded</p>
                            <p className="text-xs text-muted-foreground">
                              {Math.round(uploadedImage.length / 1024)} KB
                            </p>
                          </div>
                        </div>
                      ) : (
                        <p className="text-sm text-yellow-500">No image uploaded</p>
                      )}
                    </div>
                  </div>
                </ScrollArea>
              </TabsContent>

              {/* JSON Tab */}
              <TabsContent value="json" className="h-full mt-0">
                <div className="relative">
                  <Button
                    variant="outline"
                    size="sm"
                    className="absolute top-2 right-2 z-10"
                    onClick={handleCopy}
                  >
                    {copied ? (
                      <>
                        <Check className="h-4 w-4 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-1" />
                        Copy
                      </>
                    )}
                  </Button>
                  <ScrollArea className="h-[400px]">
                    <pre className="p-4 rounded bg-muted/50 border font-mono text-xs whitespace-pre-wrap break-all">
                      {JSON.stringify(apiRequest, null, 2)}
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </div>

        <Separator />

        <DialogFooter className="flex-col gap-2 sm:flex-row">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {analysis.warnings.length > 0 && (
              <Badge variant="secondary">
                {analysis.warnings.length} warning{analysis.warnings.length > 1 ? 's' : ''}
              </Badge>
            )}
            <Badge variant="outline">
              ~{analysis.estimatedTokens} tokens
            </Badge>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleConfirm} disabled={!uploadedImage || !positivePrompt.trim()}>
              <Send className="h-4 w-4 mr-2" />
              Confirm & Generate
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
