'use client';

import { useCallback, useEffect, useState, useRef } from 'react';
import { 
  Loader2, CheckCircle, XCircle, Clock, Sparkles, AlertTriangle,
  Upload, FileText, Cpu, Film, Check, Zap, RefreshCw
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useVideoStore } from '@/store/video-store';
import { formatTimeRemaining } from '@/lib/video-utils';
import { PerformanceModeSelector } from '@/components/performance-mode-selector';
import { PERFORMANCE_MODES, type PerformanceMode } from '@/lib/image-utils';

interface GenerationProgressProps {
  onGenerate: (mode: PerformanceMode) => Promise<void>;
  onCancel: () => void;
  onRetryWithFasterSettings?: () => void;
}

// Progress stages with their percentages
const PROGRESS_STAGES = [
  { name: 'Uploading image...', start: 0, end: 5, icon: Upload },
  { name: 'Processing prompts...', start: 5, end: 15, icon: FileText },
  { name: 'Initializing AI model...', start: 15, end: 25, icon: Cpu },
  { name: 'Generating frames 1-30...', start: 25, end: 45, icon: Film },
  { name: 'Generating frames 31-60...', start: 45, end: 65, icon: Film },
  { name: 'Generating frames 61-90...', start: 65, end: 85, icon: Film },
  { name: 'Finalizing video...', start: 85, end: 95, icon: Check },
  { name: 'Complete!', start: 95, end: 100, icon: CheckCircle },
];

const MAX_GENERATION_TIME = 180; // 3 minutes in seconds
const STUCK_THRESHOLD = 30; // 30 seconds without progress = stuck

export function GenerationProgress({ 
  onGenerate, 
  onCancel,
  onRetryWithFasterSettings 
}: GenerationProgressProps) {
  const { 
    isGenerating, 
    progress, 
    currentTask,
    uploadedImage,
    positivePrompt,
    settings,
    cancelGeneration,
  } = useVideoStore();

  const [selectedMode, setSelectedMode] = useState<PerformanceMode>('balanced');
  const [elapsedTime, setElapsedTime] = useState(0);
  const [estimatedTime, setEstimatedTime] = useState({ min: 60, max: 120 });
  const [lastProgressUpdate, setLastProgressUpdate] = useState(Date.now());
  const [isStuck, setIsStuck] = useState(false);
  const [networkSpeed, setNetworkSpeed] = useState<'fast' | 'medium' | 'slow'>('medium');
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [showModeSelector, setShowModeSelector] = useState(true);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const stuckCheckRef = useRef<NodeJS.Timeout | null>(null);

  // Determine current stage based on progress
  useEffect(() => {
    for (let i = PROGRESS_STAGES.length - 1; i >= 0; i--) {
      if (progress >= PROGRESS_STAGES[i].start) {
        setCurrentStageIndex(i);
        break;
      }
    }
  }, [progress]);

  // Update elapsed time and check for timeout
  useEffect(() => {
    if (!isGenerating || !currentTask) return;

    const startTime = new Date(currentTask.createdAt).getTime();
    
    timerRef.current = setInterval(() => {
      const now = Date.now();
      const elapsed = Math.floor((now - startTime) / 1000);
      setElapsedTime(elapsed);
      
      // Check for timeout
      if (elapsed >= MAX_GENERATION_TIME) {
        console.log('Generation timed out after 3 minutes');
        cancelGeneration();
        if (timerRef.current) clearInterval(timerRef.current);
      }
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isGenerating, currentTask, cancelGeneration]);

  // Check for stuck generation
  useEffect(() => {
    if (!isGenerating) {
      setIsStuck(false);
      return;
    }

    stuckCheckRef.current = setInterval(() => {
      const timeSinceUpdate = (Date.now() - lastProgressUpdate) / 1000;
      if (timeSinceUpdate > STUCK_THRESHOLD && progress < 95) {
        setIsStuck(true);
      }
    }, 5000);

    return () => {
      if (stuckCheckRef.current) clearInterval(stuckCheckRef.current);
    };
  }, [isGenerating, lastProgressUpdate, progress]);

  // Update last progress update time when progress changes
  useEffect(() => {
    if (isGenerating && progress > 0) {
      setLastProgressUpdate(Date.now());
      setIsStuck(false);
    }
  }, [progress, isGenerating]);

  // Estimate time based on mode
  useEffect(() => {
    const mode = PERFORMANCE_MODES[selectedMode];
    const minMax = selectedMode === 'fast' 
      ? { min: 30, max: 60 } 
      : selectedMode === 'balanced' 
        ? { min: 60, max: 120 } 
        : { min: 90, max: 180 };
    setEstimatedTime(minMax);
  }, [selectedMode]);

  const getStatusText = (): string => {
    if (!currentTask) return 'Ready to generate';
    
    switch (currentTask.status) {
      case 'PENDING':
        return 'Initializing...';
      case 'PROCESSING':
        return PROGRESS_STAGES[currentStageIndex]?.name || 'Generating...';
      case 'SUCCESS':
        return 'Generation complete!';
      case 'FAIL':
        return currentTask.error || 'Generation failed';
      case 'CANCELLED':
        return 'Generation cancelled';
      default:
        return 'Unknown status';
    }
  };

  const getStatusIcon = () => {
    if (!currentTask || currentTask.status === 'PENDING') {
      return <Sparkles className="h-5 w-5 text-muted-foreground" />;
    }
    
    switch (currentTask.status) {
      case 'PROCESSING':
        return <Loader2 className="h-5 w-5 text-primary animate-spin" />;
      case 'SUCCESS':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'FAIL':
        return <XCircle className="h-5 w-5 text-destructive" />;
      case 'CANCELLED':
        return <XCircle className="h-5 w-5 text-orange-500" />;
      default:
        return <Sparkles className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const canGenerate = uploadedImage && positivePrompt.trim().length > 0 && !isGenerating;

  const handleGenerateClick = useCallback(async () => {
    if (!canGenerate) return;
    setShowModeSelector(false);
    setElapsedTime(0);
    setLastProgressUpdate(Date.now());
    setIsStuck(false);
    await onGenerate(selectedMode);
  }, [canGenerate, onGenerate, selectedMode]);

  const handleCancelClick = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (stuckCheckRef.current) clearInterval(stuckCheckRef.current);
    cancelGeneration();
    onCancel();
    setShowModeSelector(true);
  }, [cancelGeneration, onCancel]);

  const handleRetryFaster = useCallback(() => {
    handleCancelClick();
    setSelectedMode('fast');
    onRetryWithFasterSettings?.();
  }, [handleCancelClick, onRetryWithFasterSettings]);

  const remainingTime = Math.max(0, MAX_GENERATION_TIME - elapsedTime);
  const progressPercent = Math.min(95, progress);
  const timeRemaining = Math.max(0, estimatedTime.max - elapsedTime);

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        {/* Performance Mode Selector (before generation) */}
        {showModeSelector && !isGenerating && (
          <PerformanceModeSelector
            value={selectedMode}
            onChange={setSelectedMode}
          />
        )}

        {/* Time Estimate (before generation) */}
        {!isGenerating && canGenerate && (
          <div className="p-3 rounded-lg bg-muted/50 border">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Estimated Generation Time</span>
            </div>
            <p className="text-lg font-bold text-primary">
              {estimatedTime.min}-{estimatedTime.max} seconds
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Maximum timeout: 3 minutes
            </p>
          </div>
        )}

        {/* Status Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <span className="font-medium">{getStatusText()}</span>
          </div>
          {isGenerating && (
            <div className="flex items-center gap-2">
              <Badge variant={remainingTime < 30 ? 'destructive' : 'secondary'} className="text-xs">
                <Clock className="h-3 w-3 mr-1" />
                {formatTimeRemaining(remainingTime)} remaining (max 3:00)
              </Badge>
            </div>
          )}
        </div>

        {/* Progress Bar with Stages */}
        {isGenerating && (
          <div className="space-y-3">
            {/* Stage Progress Bar */}
            <div className="relative">
              <Progress value={progressPercent} className="h-3" />
              {/* Stage markers */}
              <div className="absolute top-0 left-0 right-0 flex justify-between">
                {PROGRESS_STAGES.map((stage, i) => (
                  <div
                    key={i}
                    className={`
                      w-1 h-3 rounded-full transition-colors
                      ${progress >= stage.start ? 'bg-primary' : 'bg-muted'}
                    `}
                    style={{ left: `${stage.start}%` }}
                  />
                ))}
              </div>
            </div>

            {/* Current Stage Indicator */}
            <div className="flex items-center gap-2 p-2 rounded bg-muted/50">
              {(() => {
                const StageIcon = PROGRESS_STAGES[currentStageIndex]?.icon || Film;
                return <StageIcon className="h-4 w-4 text-primary" />;
              })()}
              <span className="text-sm">
                {PROGRESS_STAGES[currentStageIndex]?.name || 'Processing...'}
              </span>
              <Badge variant="outline" className="ml-auto text-xs">
                {Math.round(progressPercent)}%
              </Badge>
            </div>

            {/* Elapsed Time */}
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Elapsed: {formatTimeRemaining(elapsedTime)}</span>
              <span>Est. remaining: {formatTimeRemaining(timeRemaining)}</span>
            </div>
          </div>
        )}

        {/* Stuck Warning */}
        {isStuck && isGenerating && (
          <Alert variant="warning" className="border-yellow-500 bg-yellow-500/10">
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
            <AlertDescription className="text-sm">
              <p className="font-medium mb-2">Generation seems stuck</p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsStuck(false)}
                >
                  Continue Waiting
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRetryFaster}
                  className="border-yellow-500 text-yellow-600"
                >
                  <Zap className="h-3 w-3 mr-1" />
                  Retry with Fast Mode
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Slow Network Warning */}
        {networkSpeed === 'slow' && !isGenerating && canGenerate && (
          <Alert variant="warning" className="border-orange-500 bg-orange-500/10">
            <AlertTriangle className="h-4 w-4 text-orange-500" />
            <AlertDescription className="text-sm">
              <p className="font-medium">Slow connection detected</p>
              <p className="text-xs mt-1">Upload may take longer. Consider using Fast mode for better results.</p>
            </AlertDescription>
          </Alert>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          {!isGenerating ? (
            <Button
              className="flex-1"
              onClick={handleGenerateClick}
              disabled={!canGenerate}
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Generate Video
            </Button>
          ) : (
            <Button
              variant="destructive"
              className="flex-1"
              onClick={handleCancelClick}
            >
              Cancel Generation
            </Button>
          )}
        </div>

        {/* Timeout Warning */}
        {isGenerating && elapsedTime > 120 && (
          <div className="p-2 rounded bg-red-500/10 border border-red-500/30">
            <p className="text-xs text-red-600 dark:text-red-400">
              ⚠️ Generation taking longer than expected. You can cancel and retry with faster settings.
            </p>
          </div>
        )}

        {/* Validation Messages */}
        {!uploadedImage && !isGenerating && (
          <p className="text-xs text-muted-foreground text-center">
            Upload an image to start generation
          </p>
        )}
        {uploadedImage && !positivePrompt.trim() && !isGenerating && (
          <p className="text-xs text-muted-foreground text-center">
            Add a prompt describing the motion you want
          </p>
        )}

        {/* Generation Complete Actions */}
        {currentTask?.status === 'SUCCESS' && !isGenerating && (
          <div className="p-2 rounded bg-green-500/10 border border-green-500/30">
            <p className="text-xs text-green-600 dark:text-green-400 text-center">
              ✅ Video generated successfully! View it in the Output panel.
            </p>
          </div>
        )}

        {/* Generation Failed Actions */}
        {currentTask?.status === 'FAIL' && !isGenerating && (
          <div className="space-y-2">
            <div className="p-2 rounded bg-red-500/10 border border-red-500/30">
              <p className="text-xs text-red-600 dark:text-red-400 text-center">
                ❌ Generation failed. Try again or use Fast mode.
              </p>
            </div>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setSelectedMode('fast');
                handleGenerateClick();
              }}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry with Fast Mode
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
