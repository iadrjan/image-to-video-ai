import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  VideoGenerationTask,
  GenerationSettings,
  DEFAULT_SETTINGS,
  DEFAULT_NEGATIVE_PROMPT,
  HistoryItem,
} from '@/types/video';

interface VideoStore {
  // Image state
  uploadedImage: string | null;
  imageDimensions: { width: number; height: number } | null;
  
  // Prompt state
  positivePrompt: string;
  negativePrompt: string;
  
  // Settings state
  settings: GenerationSettings;
  
  // Generation state
  currentTask: VideoGenerationTask | null;
  taskHistory: VideoGenerationTask[];
  history: HistoryItem[];
  favorites: string[];
  
  // UI state
  isGenerating: boolean;
  progress: number;
  
  // Actions - Image
  setImage: (image: string, dimensions: { width: number; height: number }) => void;
  clearImage: () => void;
  
  // Actions - Prompts
  setPositivePrompt: (prompt: string) => void;
  setNegativePrompt: (prompt: string) => void;
  setPrompts: (positive: string, negative: string) => void;
  
  // Actions - Settings
  updateSettings: (settings: Partial<GenerationSettings>) => void;
  resetSettings: () => void;
  
  // Actions - Generation
  startGeneration: () => VideoGenerationTask;
  updateTaskProgress: (taskId: string, progress: number, status: VideoGenerationTask['status']) => void;
  completeGeneration: (taskId: string, videoUrl: string) => void;
  failGeneration: (taskId: string, error: string) => void;
  cancelGeneration: () => void;
  
  // Actions - History
  addToHistory: (item: HistoryItem) => void;
  removeFromHistory: (id: string) => void;
  clearHistory: () => void;
  toggleFavorite: (id: string) => void;
  restoreFromHistory: (item: HistoryItem) => void;
  
  // Actions - Export
  exportSettings: () => string;
  importSettings: (json: string) => boolean;
}

export const useVideoStore = create<VideoStore>()(
  persist(
    (set, get) => ({
      // Initial state
      uploadedImage: null,
      imageDimensions: null,
      positivePrompt: '',
      negativePrompt: DEFAULT_NEGATIVE_PROMPT,
      settings: DEFAULT_SETTINGS,
      currentTask: null,
      taskHistory: [],
      history: [],
      favorites: [],
      isGenerating: false,
      progress: 0,
      
      // Image actions
      setImage: (image, dimensions) => set({
        uploadedImage: image,
        imageDimensions: dimensions,
      }),
      
      clearImage: () => set({
        uploadedImage: null,
        imageDimensions: null,
      }),
      
      // Prompt actions
      setPositivePrompt: (prompt) => set({ positivePrompt: prompt }),
      
      setNegativePrompt: (prompt) => set({ negativePrompt: prompt }),
      
      setPrompts: (positive, negative) => set({
        positivePrompt: positive,
        negativePrompt: negative,
      }),
      
      // Settings actions
      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings },
      })),
      
      resetSettings: () => set({ settings: DEFAULT_SETTINGS }),
      
      // Generation actions
      startGeneration: () => {
        const state = get();
        const taskId = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const newTask: VideoGenerationTask = {
          id: taskId,
          taskId: null,
          status: 'PENDING',
          positivePrompt: state.positivePrompt,
          negativePrompt: state.negativePrompt,
          settings: { ...state.settings },
          sourceImage: state.uploadedImage || '',
          videoUrl: null,
          thumbnailUrl: state.uploadedImage,
          createdAt: new Date(),
          completedAt: null,
          progress: 0,
          error: null,
          isFavorite: false,
        };
        
        set({
          currentTask: newTask,
          isGenerating: true,
          progress: 0,
          taskHistory: [newTask, ...state.taskHistory].slice(0, 50),
        });
        
        return newTask;
      },
      
      updateTaskProgress: (taskId, progress, status) => {
        set((state) => {
          if (state.currentTask?.id === taskId) {
            return {
              progress,
              currentTask: { ...state.currentTask, progress, status },
            };
          }
          return {};
        });
      },
      
      completeGeneration: (taskId, videoUrl) => {
        const state = get();
        
        const historyItem: HistoryItem = {
          id: taskId,
          taskId: state.currentTask?.taskId || taskId,
          sourceImage: state.currentTask?.sourceImage || '',
          videoUrl,
          positivePrompt: state.currentTask?.positivePrompt || '',
          negativePrompt: state.currentTask?.negativePrompt || '',
          settings: state.currentTask?.settings || DEFAULT_SETTINGS,
          createdAt: new Date(),
          isFavorite: false,
        };
        
        set((state) => ({
          isGenerating: false,
          progress: 100,
          currentTask: state.currentTask ? {
            ...state.currentTask,
            status: 'SUCCESS',
            videoUrl,
            progress: 100,
            completedAt: new Date(),
          } : null,
          history: [historyItem, ...state.history].slice(0, 50),
        }));
      },
      
      failGeneration: (taskId, error) => {
        set((state) => ({
          isGenerating: false,
          progress: 0,
          currentTask: state.currentTask ? {
            ...state.currentTask,
            status: 'FAIL',
            error,
          } : null,
        }));
      },
      
      cancelGeneration: () => set((state) => ({
        isGenerating: false,
        progress: 0,
        currentTask: state.currentTask ? {
          ...state.currentTask,
          status: 'CANCELLED',
        } : null,
      })),
      
      // History actions
      addToHistory: (item) => set((state) => ({
        history: [item, ...state.history].slice(0, 50),
      })),
      
      removeFromHistory: (id) => set((state) => ({
        history: state.history.filter((item) => item.id !== id),
      })),
      
      clearHistory: () => set({ history: [], favorites: [] }),
      
      toggleFavorite: (id) => set((state) => {
        const isFavorite = state.favorites.includes(id);
        return {
          favorites: isFavorite
            ? state.favorites.filter((f) => f !== id)
            : [...state.favorites, id],
          history: state.history.map((item) =>
            item.id === id ? { ...item, isFavorite: !isFavorite } : item
          ),
        };
      }),
      
      restoreFromHistory: (item) => set({
        uploadedImage: item.sourceImage,
        positivePrompt: item.positivePrompt,
        negativePrompt: item.negativePrompt,
        settings: { ...item.settings },
      }),
      
      // Export/Import
      exportSettings: () => {
        const state = get();
        return JSON.stringify({
          positivePrompt: state.positivePrompt,
          negativePrompt: state.negativePrompt,
          settings: state.settings,
        }, null, 2);
      },
      
      importSettings: (json) => {
        try {
          const data = JSON.parse(json);
          set({
            positivePrompt: data.positivePrompt || '',
            negativePrompt: data.negativePrompt || DEFAULT_NEGATIVE_PROMPT,
            settings: { ...DEFAULT_SETTINGS, ...data.settings },
          });
          return true;
        } catch {
          return false;
        }
      },
    }),
    {
      name: 'video-generation-storage',
      partialize: (state) => ({
        positivePrompt: state.positivePrompt,
        negativePrompt: state.negativePrompt,
        settings: state.settings,
        history: state.history,
        favorites: state.favorites,
      }),
    }
  )
);
