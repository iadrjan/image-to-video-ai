import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { smartTruncatePrompt } from '@/lib/prompt-utils';
import { enhancePrompt, enhanceNegativePrompt } from '@/lib/prompt-enhancer';

// API Limits
const API_LIMITS = {
  maxPromptLength: 10000,
  maxNegativePromptLength: 10000,
  maxTotalLength: 20000,
};

// Request/Response logging for debugging
function logApiInteraction(type: 'request' | 'response', data: any) {
  const timestamp = new Date().toISOString();
  console.log(`\n${'='.repeat(70)}`);
  console.log(`[${timestamp}] VIDEO API ${type.toUpperCase()}`);
  console.log('='.repeat(70));
  
  if (type === 'request') {
    console.log('Image:', data.image ? `[Base64 - ${Math.round(data.image.length / 1024)}KB]` : 'None');
    console.log('\n--- POSITIVE PROMPT (ENHANCED) ---');
    console.log('Original length:', data.originalPromptLength || 0);
    console.log('Enhanced length:', data.prompt?.length || 0);
    console.log('Prompt:', data.prompt?.substring(0, 500) + (data.prompt?.length > 500 ? '...' : ''));
    
    console.log('\n--- NEGATIVE PROMPT ---');
    console.log('Length:', data.negativePrompt?.length || 0);
    console.log('First 500 chars:', data.negativePrompt?.substring(0, 500));
    
    console.log('\n--- SETTINGS ---');
    console.log(JSON.stringify(data.settings, null, 2));
    
    console.log('\n--- ENHANCEMENTS APPLIED ---');
    console.log('Motion terms added:', data.enhancements?.motionTerms || []);
    console.log('Expansions:', data.enhancements?.expansions || []);
  } else {
    console.log('Task ID:', data.taskId);
    console.log('Status:', data.status);
    console.log('Success:', data.success);
    if (data.error) console.log('Error:', data.error);
  }
  console.log('='.repeat(70) + '\n');
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { image, prompt, negativePrompt, settings, skipEnhancement } = body;

    // Validation
    if (!image) {
      return NextResponse.json(
        { error: 'Image is required', success: false },
        { status: 400 }
      );
    }

    if (!prompt || prompt.trim().length === 0) {
      return NextResponse.json(
        { error: 'Positive prompt is required', success: false },
        { status: 400 }
      );
    }

    // ENHANCE PROMPTS - This is critical for good results
    let finalPositivePrompt = prompt.trim();
    let finalNegativePrompt = negativePrompt?.trim() || '';
    
    const originalPromptLength = finalPositivePrompt.length;
    const originalNegativeLength = finalNegativePrompt.length;
    
    const enhancements: {
      motionTerms: string[];
      expansions: string[];
      additions: string[];
    } = {
      motionTerms: [],
      expansions: [],
      additions: [],
    };

    // Skip enhancement if explicitly requested (for advanced users)
    if (!skipEnhancement) {
      // Enhance positive prompt
      const positiveEnhancement = enhancePrompt(finalPositivePrompt, {
        duration: settings?.duration || 5,
        addCameraStability: true,
        addMotionTerms: true,
        useWeights: false, // API may not support weights
      });
      
      finalPositivePrompt = positiveEnhancement.enhanced;
      enhancements.motionTerms = positiveEnhancement.motionTerms;
      enhancements.expansions = positiveEnhancement.expansions;
      
      // Enhance negative prompt
      const negativeEnhancement = enhanceNegativePrompt(finalNegativePrompt);
      finalNegativePrompt = negativeEnhancement.enhanced;
      enhancements.additions = negativeEnhancement.additions;
    }

    // Track any modifications made
    const modifications: string[] = [];
    const truncationWarnings: string[] = [];

    // Add motion intensity terms if specified
    if (settings?.motionIntensity && settings.motionIntensity !== 5) {
      const motionTerms: Record<number, string> = {
        1: 'very subtle minimal motion, extremely gentle, almost static',
        2: 'subtle motion, gentle movement, soft',
        3: 'light movement, smooth transition, calm',
        4: 'moderate motion, natural relaxed movement',
        6: 'active motion, dynamic movement, lively',
        7: 'energetic motion, pronounced movement',
        8: 'strong motion, powerful dynamic movement',
        9: 'intense motion, very dynamic movement',
        10: 'extreme motion, maximum dynamic powerful movement',
      };

      const motionTerm = motionTerms[settings.motionIntensity];
      if (motionTerm) {
        finalPositivePrompt = `${finalPositivePrompt}, ${motionTerm}`;
        modifications.push(`Motion intensity: "${motionTerm}"`);
      }
    }

    // Check if truncation is needed
    const totalLength = finalPositivePrompt.length + finalNegativePrompt.length;
    
    if (totalLength > API_LIMITS.maxTotalLength || finalNegativePrompt.length > API_LIMITS.maxNegativePromptLength) {
      if (finalNegativePrompt.length > API_LIMITS.maxNegativePromptLength) {
        const result = smartTruncatePrompt(finalNegativePrompt, API_LIMITS.maxNegativePromptLength, 'important');
        if (result.wasTruncated) {
          truncationWarnings.push(`Negative prompt condensed: removed ${result.removedTerms.length} terms`);
          finalNegativePrompt = result.truncated;
          console.log('Removed negative prompt terms:', result.removedTerms.slice(0, 10));
        }
      }
      
      const remainingSpace = API_LIMITS.maxTotalLength - finalPositivePrompt.length - 100;
      if (finalNegativePrompt.length > remainingSpace && remainingSpace > 500) {
        const originalLength = finalNegativePrompt.length;
        finalNegativePrompt = finalNegativePrompt.substring(0, remainingSpace);
        truncationWarnings.push(`Negative prompt truncated: ${originalLength - remainingSpace} chars removed`);
      }
    }

    // Prepare the request for API
    const apiRequest: any = {
      image_url: image,
      prompt: finalPositivePrompt,
      quality: settings?.quality || 'quality',
      duration: settings?.duration || 5,
      fps: settings?.fps || 30,
      size: settings?.resolution || '1920x1080',
    };

    // Note: z-ai-web-dev-sdk may not support negative_prompt directly
    // We include it in the prompt if not supported as a separate parameter
    // Check SDK documentation for negative prompt support
    
    // Log everything for debugging
    logApiInteraction('request', {
      image: image ? '[Base64 image]' : null,
      originalPromptLength,
      prompt: finalPositivePrompt,
      negativePrompt: finalNegativePrompt,
      settings: apiRequest,
      enhancements,
    });

    // Initialize ZAI SDK and create task
    const zai = await ZAI.create();
    
    const task = await zai.video.generations.create(apiRequest);

    // Prepare response with full debug info
    const response = {
      success: true,
      taskId: task.id,
      status: task.task_status,
      
      // Prompt debugging info
      promptsSent: {
        originalPositiveLength: originalPromptLength,
        originalNegativeLength: originalNegativeLength,
        positiveLength: finalPositivePrompt.length,
        negativeLength: finalNegativePrompt.length,
        positivePrompt: finalPositivePrompt.substring(0, 500) + (finalPositivePrompt.length > 500 ? '...' : ''),
        negativePromptPreview: finalNegativePrompt.substring(0, 300) + '...',
      },
      
      // Enhancement info
      enhancements,
      modifications,
      truncationWarnings,
      
      // API capability note
      apiNote: 'Negative prompts may not be directly supported by all video APIs. Enhanced prompt includes motion directives.',
    };

    // Log the response
    logApiInteraction('response', response);

    return NextResponse.json(response);

  } catch (error: any) {
    console.error('\n!!! VIDEO GENERATION ERROR !!!');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    const errorResponse = {
      success: false,
      error: error.message || 'Failed to create video generation task',
      details: error.toString(),
    };
    
    logApiInteraction('response', errorResponse);

    return NextResponse.json(
      errorResponse,
      { status: 500 }
    );
  }
}
