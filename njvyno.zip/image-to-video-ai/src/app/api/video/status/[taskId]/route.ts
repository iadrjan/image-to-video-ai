import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Response logging for debugging
function logStatusCheck(taskId: string, result: any) {
  const timestamp = new Date().toISOString();
  console.log(`\n${'-'.repeat(40)}`);
  console.log(`[${timestamp}] STATUS CHECK: ${taskId}`);
  console.log(`Status: ${result.task_status}`);
  
  if (result.task_status === 'SUCCESS') {
    const videoUrl = result.video_result?.[0]?.url ||
                     result.video_url ||
                     result.url ||
                     result.video;
    console.log(`Video URL: ${videoUrl ? videoUrl.substring(0, 100) + '...' : 'Not found'}`);
  } else if (result.task_status === 'FAIL') {
    console.log(`Failure reason:`, result);
  }
  
  console.log('-'.repeat(40) + '\n');
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const { taskId } = await params;

    if (!taskId) {
      return NextResponse.json(
        { error: 'Task ID is required', success: false },
        { status: 400 }
      );
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    // Query task status
    const result = await zai.async.result.query(taskId);

    // Log the status check
    logStatusCheck(taskId, result);

    const response: any = {
      taskId: taskId,
      status: result.task_status,
      timestamp: new Date().toISOString(),
    };

    // If successful, extract video URL from multiple possible fields
    if (result.task_status === 'SUCCESS') {
      const videoUrl = (result as any).video_result?.[0]?.url ||
                       (result as any).video_url ||
                       (result as any).url ||
                       (result as any).video;
      
      if (videoUrl) {
        response.videoUrl = videoUrl;
        response.success = true;
        console.log(`\n✅ VIDEO GENERATION SUCCESS`);
        console.log(`Task ID: ${taskId}`);
        console.log(`Video URL: ${videoUrl}\n`);
      } else {
        // Log full result for debugging if URL not found
        console.log('\n⚠️ Video URL not found in expected fields. Full result:');
        console.log(JSON.stringify(result, null, 2));
        response.videoUrl = null;
        response.warning = 'Video URL not found in expected response fields';
        response.rawResult = result;
      }
    }

    // If failed, include error info
    if (result.task_status === 'FAIL') {
      response.success = false;
      response.error = 'Video generation failed';
      response.details = result;
      console.log(`\n❌ VIDEO GENERATION FAILED`);
      console.log(`Task ID: ${taskId}`);
      console.log(`Details:`, result);
    }

    // If processing, include estimated wait time
    if (result.task_status === 'PROCESSING') {
      response.message = 'Video is still being generated...';
    }

    return NextResponse.json(response);

  } catch (error: any) {
    console.error('\n!!! STATUS CHECK ERROR !!!');
    console.error('Error message:', error.message);
    
    return NextResponse.json(
      { 
        error: error.message || 'Failed to query task status',
        success: false,
        status: 'ERROR'
      },
      { status: 500 }
    );
  }
}
