import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Image to Video AI - Transform Images into Videos",
  description: "Transform your images into stunning videos using AI. Upload an image, describe the motion, and generate professional-quality videos in seconds.",
  keywords: ["AI video", "image to video", "video generation", "AI animation", "video creator", "motion synthesis"],
  authors: [{ name: "AI Video Generator" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Image to Video AI Generator",
    description: "Transform images into stunning AI-generated videos",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
