'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Video, Sparkles, Menu, PanelLeftClose, PanelRightClose } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Toaster, toast } from 'sonner';
import { ImageUpload } from '@/components/image-upload';
import { PromptSection } from '@/components/prompt-section';
import { GenerationSettings } from '@/components/generation-settings';
import { GenerationProgress } from '@/components/generation-progress';
import { VideoOutput } from '@/components/video-output';
import { GenerationHistory } from '@/components/generation-history';
import { PromptHealthCheck } from '@/components/prompt-health-check';
import { ApiPreviewDialog } from '@/components/api-preview-dialog';
import { useVideoStore } from '@/store/video-store';
import { preparePromptsForApi } from '@/lib/prompt-utils';
import { processImageForApi, checkNetworkSpeed, type PerformanceMode } from '@/lib/image-utils';

export default function Home() {
  const {
    uploadedImage,
    positivePrompt,
    negativePrompt,
    settings,
    currentTask,
    isGenerating,
    startGeneration,
    updateTaskProgress,
    completeGeneration,
    failGeneration,
    cancelGeneration,
    updateSettings,
  } = useVideoStore();

  const [showLeftPanel, setShowLeftPanel] = useState(true);
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [showApiPreview, setShowApiPreview] = useState(false);
  const [generationLog, setGenerationLog] = useState<string[]>([]);
  const [networkSpeed, setNetworkSpeed] = useState<'fast' | 'medium' | 'slow'>('medium');
  const [imageOptimized, setImageOptimized] = useState(false);
  
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const progressSimulationRef = useRef<NodeJS.Timeout | null>(null);

  // Check for mobile and network speed on mount
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth < 768) {
        setShowLeftPanel(false);
        setShowRightPanel(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Check network speed
    checkNetworkSpeed().then(result => {
      setNetworkSpeed(result.speed);
    });
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Add to generation log
  const addLog = useCallback((message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setGenerationLog(prev => [...prev, `[${timestamp}] ${message}`]);
    console.log(`[${timestamp}] ${message}`);
  }, []);

  // Simulate progress for better UX
  const startProgressSimulation = useCallback(() => {
    // Clear any existing simulation
    if (progressSimulationRef.current) {
      clearInterval(progressSimulationRef.current);
    }

    let currentProgress = 5;
    const targetProgress = 85;
    
    progressSimulationRef.current = setInterval(() => {
      // Slowly increase progress towards target
      if (currentProgress < targetProgress) {
        // Progress slows down as it gets closer to target
        const increment = Math.max(0.5, (targetProgress - currentProgress) / 50);
        currentProgress += increment;
        updateTaskProgress(currentTask?.id || '', Math.min(currentProgress, targetProgress), 'PROCESSING');
      }
    }, 2000);
  }, [currentTask?.id, updateTaskProgress]);

  // Stop progress simulation
  const stopProgressSimulation = useCallback(() => {
    if (progressSimulationRef.current) {
      clearInterval(progressSimulationRef.current);
      progressSimulationRef.current = null;
    }
  }, []);

  // Polling logic for video generation
  const pollTaskStatus = useCallback(async (taskId: string) => {
    try {
      addLog(`Checking status for task: ${taskId.substring(0, 20)}...`);
      
      const response = await fetch(`/api/video/status/${taskId}`);
      const data = await response.json();

      addLog(`Status: ${data.status}`);

      if (data.status === 'SUCCESS') {
        if (pollingRef.current) {
          clearInterval(pollingRef.current);
          pollingRef.current = null;
        }
        stopProgressSimulation();
        
        if (data.videoUrl) {
          updateTaskProgress(currentTask?.id || '', 100, 'SUCCESS');
          completeGeneration(currentTask?.id || '', data.videoUrl);
          addLog(`✅ Video generated successfully!`);
          toast.success('Video generated successfully!');
          
          console.log('\n🎬 VIDEO READY!');
          console.log('Video URL:', data.videoUrl);
        } else {
          failGeneration(currentTask?.id || '', 'Video URL not found in response');
          addLog(`❌ Error: Video URL not found`);
          toast.error('Video URL not found in response');
        }
        return true;
      }

      if (data.status === 'FAIL') {
        if (pollingRef.current) {
          clearInterval(pollingRef.current);
          pollingRef.current = null;
        }
        stopProgressSimulation();
        failGeneration(currentTask?.id || '', data.error || 'Generation failed');
        addLog(`❌ Generation failed: ${data.error}`);
        toast.error(data.error || 'Video generation failed');
        return true;
      }

      return false;
    } catch (error: any) {
      addLog(`❌ Polling error: ${error.message}`);
      console.error('Polling error:', error);
      return false;
    }
  }, [currentTask, completeGeneration, failGeneration, updateTaskProgress, stopProgressSimulation, addLog]);

  // Start polling when generation starts
  useEffect(() => {
    if (isGenerating && currentTask?.taskId) {
      // Start progress simulation
      startProgressSimulation();
      
      // Poll every 5 seconds
      pollingRef.current = setInterval(() => {
        pollTaskStatus(currentTask.taskId!);
      }, 5000);

      // Initial poll after 10 seconds
      setTimeout(() => {
        pollTaskStatus(currentTask.taskId!);
      }, 10000);

      return () => {
        if (pollingRef.current) {
          clearInterval(pollingRef.current);
          pollingRef.current = null;
        }
        stopProgressSimulation();
      };
    }
  }, [isGenerating, currentTask?.taskId, pollTaskStatus, startProgressSimulation, stopProgressSimulation]);

  // Execute generation with performance mode
  const executeGeneration = useCallback(async (mode: PerformanceMode) => {
    if (!uploadedImage) {
      toast.error('Please upload an image first');
      return;
    }

    if (!positivePrompt.trim()) {
      toast.error('Please enter a prompt');
      return;
    }

    // Start generation in store
    const task = startGeneration();
    addLog('Starting video generation...');
    addLog(`Performance mode: ${mode}`);
    
    // Prepare prompts
    const preparedPrompts = preparePromptsForApi(positivePrompt, negativePrompt, {
      motionIntensity: settings.motionIntensity,
    });

    // Log warnings if any
    if (preparedPrompts.warnings.length > 0) {
      preparedPrompts.warnings.forEach(w => {
        addLog(`⚠️ ${w}`);
        toast.warning(w);
      });
    }

    try {
      // Step 1: Optimize image (show progress)
      updateTaskProgress(task.id, 2, 'PROCESSING');
      addLog('Optimizing image...');
      
      let optimizedImage = uploadedImage;
      if (!imageOptimized) {
        const result = await processImageForApi(uploadedImage, {
          maxDimension: 2048,
          quality: 0.9,
          targetSizeKB: 2000,
        });
        
        optimizedImage = result.optimized;
        if (result.wasResized) {
          addLog(`Image resized and compressed: ${Math.round(result.originalSize / 1024)}KB → ${Math.round(result.outputSize / 1024)}KB`);
        }
      }

      // Step 2: Send to API
      updateTaskProgress(task.id, 10, 'PROCESSING');
      addLog(`Positive prompt: ${preparedPrompts.finalPositivePrompt.length} chars`);
      addLog(`Negative prompt: ${preparedPrompts.finalNegativePrompt.length} chars`);
      addLog('Sending request to API...');

      const response = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: optimizedImage,
          prompt: preparedPrompts.finalPositivePrompt,
          negativePrompt: preparedPrompts.finalNegativePrompt,
          settings: {
            duration: settings.duration,
            fps: settings.fps,
            resolution: settings.resolution,
            quality: settings.quality,
            motionIntensity: settings.motionIntensity,
            seed: settings.seed,
          },
        }),
      });

      const data = await response.json();
      
      if (data.promptsSent) {
        addLog(`API received - Positive: ${data.promptsSent.positiveLength} chars, Negative: ${data.promptsSent.negativeLength} chars`);
      }
      
      if (data.truncationWarnings?.length > 0) {
        data.truncationWarnings.forEach((w: string) => {
          addLog(`⚠️ ${w}`);
          toast.warning(w);
        });
      }

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to start generation');
      }

      // Update task with API task ID
      updateTaskProgress(task.id, 25, 'PROCESSING');
      
      useVideoStore.setState((state) => ({
        currentTask: state.currentTask ? {
          ...state.currentTask,
          taskId: data.taskId,
        } : null,
      }));

      addLog(`Task created: ${data.taskId}`);
      addLog(`Estimated time: ${settings.duration === 10 ? '90-180' : '45-90'} seconds`);
      
      const modeMessages: Record<PerformanceMode, string> = {
        fast: 'Fast mode: Expected 30-60 seconds',
        balanced: 'Balanced mode: Expected 60-120 seconds',
        quality: 'Quality mode: Expected 90-180 seconds',
      };
      toast.success(modeMessages[mode] || 'Video generation started!');

    } catch (error: any) {
      console.error('Generation error:', error);
      addLog(`❌ Error: ${error.message}`);
      failGeneration(task.id, error.message);
      toast.error(error.message || 'Failed to start generation');
    }
  }, [uploadedImage, positivePrompt, negativePrompt, settings, startGeneration, updateTaskProgress, failGeneration, addLog, imageOptimized]);

  // Handle generate from preview dialog
  const handleGenerateFromPreview = useCallback(() => {
    executeGeneration('balanced');
  }, [executeGeneration]);

  // Handle generate button click with mode
  const handleGenerateWithMode = useCallback((mode: PerformanceMode) => {
    executeGeneration(mode);
  }, [executeGeneration]);

  // Handle cancel
  const handleCancel = useCallback(() => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
    stopProgressSimulation();
    cancelGeneration();
    addLog('Generation cancelled by user');
    toast.info('Generation cancelled');
  }, [cancelGeneration, stopProgressSimulation, addLog]);

  // Handle retry with faster settings
  const handleRetryFaster = useCallback(() => {
    addLog('Retrying with faster settings...');
    updateSettings({
      quality: 'speed',
      duration: 5,
      resolution: '1280x720',
    });
  }, [updateSettings, addLog]);

  // Settings Panel Content
  const SettingsPanel = () => (
    <div className="space-y-4">
      <PromptSection />
      <PromptHealthCheck onPreviewRequest={() => setShowApiPreview(true)} />
      <GenerationSettings />
      
      {/* Generation Log */}
      {generationLog.length > 0 && (
        <div className="p-3 rounded-lg bg-muted/30 border">
          <p className="text-xs font-medium mb-2">Generation Log:</p>
          <div className="max-h-32 overflow-y-auto">
            {generationLog.slice(-10).map((log, i) => (
              <p key={i} className="text-xs text-muted-foreground font-mono">{log}</p>
            ))}
          </div>
        </div>
      )}
      
      {/* Network Status */}
      {networkSpeed === 'slow' && (
        <div className="p-2 rounded bg-orange-500/10 border border-orange-500/30">
          <p className="text-xs text-orange-600 dark:text-orange-400">
            ⚠️ Slow network detected. Uploads may take longer.
          </p>
        </div>
      )}
    </div>
  );

  // Output Panel Content
  const OutputPanel = () => (
    <div className="space-y-4">
      <VideoOutput />
      <GenerationHistory />
    </div>
  );

  // Calculate grid columns based on panel visibility
  const getGridClass = () => {
    if (isMobile) return 'grid-cols-1';
    if (showLeftPanel && showRightPanel) return 'grid-cols-12';
    if (showLeftPanel || showRightPanel) return 'grid-cols-12';
    return 'grid-cols-1';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 p-4 overflow-y-auto">
                  <SettingsPanel />
                </SheetContent>
              </Sheet>
            )}
            
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-gradient-to-br from-primary to-primary/60">
                <Video className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                  Image to Video
                </h1>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isMobile && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowLeftPanel(!showLeftPanel)}
                  className="gap-1.5"
                >
                  <PanelLeftClose className={`h-4 w-4 transition-transform ${showLeftPanel ? '' : 'rotate-180'}`} />
                  Settings
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowRightPanel(!showRightPanel)}
                  className="gap-1.5"
                >
                  <PanelRightClose className={`h-4 w-4 transition-transform ${showRightPanel ? 'rotate-180' : ''}`} />
                  Output
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-4">
        <div className={`grid ${getGridClass()} gap-4`}>
          {/* Left Panel - Settings */}
          {!isMobile && showLeftPanel && (
            <div className="col-span-3 space-y-4">
              <SettingsPanel />
            </div>
          )}

          {/* Center Panel - Image Upload & Generation */}
          <div className={`${isMobile ? 'col-span-1' : showLeftPanel && showRightPanel ? 'col-span-6' : showLeftPanel || showRightPanel ? 'col-span-9' : 'col-span-12'} space-y-4`}>
            <ImageUpload />
            <GenerationProgress 
              onGenerate={handleGenerateWithMode} 
              onCancel={handleCancel}
              onRetryWithFasterSettings={handleRetryFaster}
            />
            
            {/* Mobile Output Section */}
            {isMobile && currentTask?.videoUrl && (
              <VideoOutput />
            )}
          </div>

          {/* Right Panel - Output */}
          {!isMobile && showRightPanel && (
            <div className="col-span-3 space-y-4">
              <OutputPanel />
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-2 text-sm text-muted-foreground">
            <p>Powered by AI • Max 3 min timeout • Auto image optimization</p>
            <div className="flex items-center gap-4">
              <span>Fast mode: ~30-60s • Balanced: ~60-120s • Quality: ~90-180s</span>
            </div>
          </div>
        </div>
      </footer>

      {/* API Preview Dialog */}
      <ApiPreviewDialog
        open={showApiPreview}
        onOpenChange={setShowApiPreview}
        onConfirm={handleGenerateFromPreview}
      />

      <Toaster position="bottom-right" />
    </div>
  );
}
