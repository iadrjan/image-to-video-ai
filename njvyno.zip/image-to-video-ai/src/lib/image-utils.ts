// Comprehensive image handling utilities

export interface ImageProcessingResult {
  optimized: string;
  originalFormat: string;
  outputFormat: string;
  originalWidth: number;
  originalHeight: number;
  outputWidth: number;
  outputHeight: number;
  originalSize: number;
  outputSize: number;
  wasConverted: boolean;
  wasResized: boolean;
  wasCompressed: boolean;
  changes: string[];
}

// Supported input formats (we accept ALL of these)
const SUPPORTED_INPUT_FORMATS = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/bmp',
  'image/tiff',
  'image/heic',
  'image/heif',
  'image/avif',
];

// Output format for API (JPEG is most compatible)
const OUTPUT_FORMAT = 'image/jpeg';
const OUTPUT_QUALITY = 0.92; // 92% quality - good balance

// Size limits
const MAX_DIMENSION = 2048;
const MIN_DIMENSION = 256;
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB input limit
const TARGET_OUTPUT_SIZE = 2 * 1024 * 1024; // 2MB target output

/**
 * Detect image format from file or base64
 */
export function detectImageFormat(input: File | string): string {
  if (typeof input === 'string') {
    // Base64 data URL
    const match = input.match(/^data:([^;]+);base64,/);
    if (match) {
      return match[1].toLowerCase();
    }
    return 'unknown';
  }
  
  // File object
  return input.type?.toLowerCase() || 'unknown';
}

/**
 * Check if format is supported
 */
export function isFormatSupported(format: string): boolean {
  const normalized = format.toLowerCase();
  return SUPPORTED_INPUT_FORMATS.some(f => f.toLowerCase() === normalized) || 
         normalized.startsWith('image/');
}

/**
 * Get format display name
 */
export function getFormatDisplayName(mimeType: string): string {
  const formats: Record<string, string> = {
    'image/jpeg': 'JPEG',
    'image/jpg': 'JPEG',
    'image/png': 'PNG',
    'image/webp': 'WebP',
    'image/gif': 'GIF',
    'image/bmp': 'BMP',
    'image/tiff': 'TIFF',
    'image/heic': 'HEIC',
    'image/heif': 'HEIF',
    'image/avif': 'AVIF',
  };
  return formats[mimeType.toLowerCase()] || mimeType.replace('image/', '').toUpperCase();
}

/**
 * Process and optimize image for API
 * - Accepts ANY image format
 * - Auto-converts to JPEG
 * - Auto-resizes to max 2048px
 * - Compresses to target size
 */
export async function processImageForApi(
  input: File | string,
  options: {
    maxDimension?: number;
    minDimension?: number;
    quality?: number;
    targetSizeKB?: number;
  } = {}
): Promise<ImageProcessingResult> {
  const {
    maxDimension = MAX_DIMENSION,
    minDimension = MIN_DIMENSION,
    quality = OUTPUT_QUALITY,
    targetSizeKB = TARGET_OUTPUT_SIZE / 1024,
  } = options;

  const changes: string[] = [];
  
  // Get base64 from input
  let base64: string;
  let originalFormat: string;
  let originalSize: number;

  if (typeof input === 'string') {
    base64 = input;
    originalFormat = detectImageFormat(input);
    originalSize = Math.round(input.length * 0.75); // Approximate size from base64
  } else {
    base64 = await fileToBase64(input);
    originalFormat = input.type || detectImageFormat(base64);
    originalSize = input.size;
  }

  // Load image
  const img = await loadImage(base64);
  let outputWidth = img.width;
  let outputHeight = img.height;

  const originalWidth = img.width;
  const originalHeight = img.height;

  // Check if conversion is needed
  const needsConversion = originalFormat !== OUTPUT_FORMAT;
  if (needsConversion) {
    changes.push(`Converted from ${getFormatDisplayName(originalFormat)} to JPEG`);
  }

  // Check if resize is needed
  let wasResized = false;
  if (img.width > maxDimension || img.height > maxDimension) {
    const ratio = Math.min(maxDimension / img.width, maxDimension / img.height);
    outputWidth = Math.round(img.width * ratio);
    outputHeight = Math.round(img.height * ratio);
    wasResized = true;
    changes.push(`Resized from ${img.width}×${img.height} to ${outputWidth}×${outputHeight}`);
  } else if (img.width < minDimension && img.height < minDimension) {
    // Upscale small images
    const ratio = Math.max(minDimension / img.width, minDimension / img.height);
    outputWidth = Math.round(img.width * ratio);
    outputHeight = Math.round(img.height * ratio);
    wasResized = true;
    changes.push(`Upscaled from ${img.width}×${img.height} to ${outputWidth}×${outputHeight}`);
  }

  // Create canvas and draw
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }

  canvas.width = outputWidth;
  canvas.height = outputHeight;
  
  // Use high quality settings
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, outputWidth, outputHeight);

  // Convert to JPEG with compression
  let output = canvas.toDataURL(OUTPUT_FORMAT, quality);
  let outputSize = Math.round(output.length * 0.75);
  let wasCompressed = false;

  // If still too large, reduce quality progressively
  let currentQuality = quality;
  while (outputSize > targetSizeKB * 1024 && currentQuality > 0.5) {
    currentQuality -= 0.05;
    output = canvas.toDataURL(OUTPUT_FORMAT, currentQuality);
    outputSize = Math.round(output.length * 0.75);
    wasCompressed = true;
  }

  if (wasCompressed) {
    changes.push(`Compressed from ${formatBytes(originalSize)} to ${formatBytes(outputSize)}`);
  }

  // If we upscaled, note that
  if (img.width < minDimension || img.height < minDimension) {
    changes.push(`Image was upscaled for better quality`);
  }

  return {
    optimized: output,
    originalFormat,
    outputFormat: OUTPUT_FORMAT,
    originalWidth,
    originalHeight,
    outputWidth,
    outputHeight,
    originalSize,
    outputSize,
    wasConverted: needsConversion,
    wasResized,
    wasCompressed,
    changes,
  };
}

/**
 * Load image from base64 or URL
 */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = src;
  });
}

/**
 * Convert File to base64
 */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert file to base64'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Format bytes to human readable
 */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

/**
 * Get image dimensions from base64
 */
export function getImageDimensions(base64: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.width, height: img.height });
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = base64;
  });
}

/**
 * Validate image and return info (never reject, just report)
 */
export async function validateImage(file: File): Promise<{
  valid: true;
  format: string;
  size: number;
  dimensions: { width: number; height: number };
  message: string;
}> {
  const format = file.type || 'unknown';
  const size = file.size;
  
  // Try to get dimensions
  let dimensions = { width: 0, height: 0 };
  try {
    const base64 = await fileToBase64(file);
    dimensions = await getImageDimensions(base64);
  } catch {
    // Still valid, just couldn't get dimensions
  }

  // Build message
  let message = `${getFormatDisplayName(format)} • ${formatBytes(size)}`;
  if (dimensions.width > 0) {
    message += ` • ${dimensions.width}×${dimensions.height}`;
  }

  return {
    valid: true,
    format,
    size,
    dimensions,
    message,
  };
}

/**
 * Check network speed
 */
export async function checkNetworkSpeed(): Promise<{
  speed: 'fast' | 'medium' | 'slow';
}> {
  try {
    const start = performance.now();
    await fetch('/api/video/status/test', { method: 'HEAD' }).catch(() => null);
    const elapsed = performance.now() - start;
    
    if (elapsed < 200) {
      return { speed: 'fast' };
    } else if (elapsed < 1000) {
      return { speed: 'medium' };
    } else {
      return { speed: 'slow' };
    }
  } catch {
    return { speed: 'medium' };
  }
}

/**
 * Performance mode presets
 */
export const PERFORMANCE_MODES = {
  fast: {
    name: 'Fast Mode',
    description: '~30-60 seconds',
    settings: {
      quality: 'speed' as const,
      duration: 5 as const,
      resolution: '1280x720',
    },
  },
  balanced: {
    name: 'Balanced Mode',
    description: '~60-120 seconds',
    settings: {
      quality: 'quality' as const,
      duration: 5 as const,
      resolution: '1920x1080',
    },
  },
  quality: {
    name: 'Best Quality',
    description: '~90-180 seconds',
    settings: {
      quality: 'quality' as const,
      duration: 10 as const,
      resolution: '1920x1080',
    },
  },
};

export type PerformanceMode = keyof typeof PERFORMANCE_MODES;
