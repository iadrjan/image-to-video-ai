// Video utility functions

import type { GenerationSettings } from '@/types/video';

// Validate image file
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
  const maxSize = 10 * 1024 * 1024; // 10MB
  
  if (!validTypes.includes(file.type)) {
    return { valid: false, error: 'Invalid file format. Please upload JPG, PNG, or WEBP images.' };
  }
  
  if (file.size > maxSize) {
    return { valid: false, error: 'File too large. Maximum size is 10MB.' };
  }
  
  return { valid: true };
}

// Convert file to base64
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert file to base64'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

// Get image dimensions from base64
export function getImageDimensions(base64: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      resolve({ width: img.width, height: img.height });
    };
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = base64;
  });
}

// Format file size
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Format duration
export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Format time remaining
export function formatTimeRemaining(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}m ${secs}s`;
}

// Download video from URL
export async function downloadVideo(url: string, filename: string = 'generated-video.mp4'): Promise<void> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);
  } catch (error) {
    console.error('Failed to download video:', error);
    // Fallback: open in new tab
    window.open(url, '_blank');
  }
}

// Enhance prompt with motion intensity
export function enhancePromptWithMotion(prompt: string, motionIntensity: number): string {
  if (motionIntensity === 5) return prompt; // Default, no enhancement needed
  
  const motionTerms: Record<number, string> = {
    1: 'subtle, minimal motion, gentle, calm',
    2: 'gentle motion, soft movement',
    3: 'light movement, smooth transition',
    4: 'moderate motion, natural movement',
    5: '', // Default
    6: 'dynamic motion, active movement',
    7: 'energetic motion, lively movement',
    8: 'strong motion, pronounced movement',
    9: 'intense motion, dramatic movement',
    10: 'extreme motion, powerful dynamic movement',
  };
  
  const motionTerm = motionTerms[motionIntensity];
  if (motionTerm) {
    return `${prompt}, ${motionTerm}`;
  }
  
  return prompt;
}

// Get resolution label
export function getResolutionLabel(resolution: GenerationSettings['resolution']): string {
  const labels: Record<string, string> = {
    '1280x720': '720p',
    '1920x1080': '1080p',
    '1024x1024': 'Square',
    '720x1440': 'Portrait',
    '1440x720': 'Landscape',
  };
  
  return labels[resolution] || resolution;
}

// Estimate generation time based on settings
export function estimateGenerationTime(settings: GenerationSettings): number {
  // Base time in seconds
  let baseTime = 60;
  
  // Adjust for duration
  baseTime += settings.duration * 10;
  
  // Adjust for quality
  if (settings.quality === 'quality') {
    baseTime *= 1.5;
  }
  
  // Adjust for fps
  if (settings.fps === 60) {
    baseTime *= 1.3;
  }
  
  // Adjust for resolution
  if (settings.resolution === '1920x1080') {
    baseTime *= 1.4;
  }
  
  return Math.round(baseTime);
}

// Generate unique ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Debounce function
export function debounce<T extends (...args: Parameters<T>) => ReturnType<T>>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null;
  
  return (...args: Parameters<T>) => {
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => func(...args), wait);
  };
}

// Throttle function
export function throttle<T extends (...args: Parameters<T>) => ReturnType<T>>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle = false;
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
}

// Check if video URL is valid
export async function isValidVideoUrl(url: string): Promise<boolean> {
  try {
    const response = await fetch(url, { method: 'HEAD' });
    const contentType = response.headers.get('content-type');
    return contentType?.startsWith('video/') || false;
  } catch {
    return false;
  }
}
