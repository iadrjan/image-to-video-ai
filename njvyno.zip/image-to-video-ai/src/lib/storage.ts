// Local storage utilities

import { UserPreferences, HistoryItem, GenerationSettings, DEFAULT_SETTINGS, DEFAULT_NEGATIVE_PROMPT } from '@/types/video';

const STORAGE_KEYS = {
  USER_PREFERENCES: 'video-gen-preferences',
  HISTORY: 'video-gen-history',
  FAVORITES: 'video-gen-favorites',
};

// Save user preferences
export function saveUserPreferences(preferences: Partial<UserPreferences>): void {
  if (typeof window === 'undefined') return;
  
  const existing = getUserPreferences();
  const updated = { ...existing, ...preferences };
  localStorage.setItem(STORAGE_KEYS.USER_PREFERENCES, JSON.stringify(updated));
}

// Get user preferences
export function getUserPreferences(): UserPreferences {
  if (typeof window === 'undefined') {
    return {
      positivePrompt: '',
      negativePrompt: DEFAULT_NEGATIVE_PROMPT,
      settings: DEFAULT_SETTINGS,
      theme: 'dark',
    };
  }
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.USER_PREFERENCES);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load user preferences:', e);
  }
  
  return {
    positivePrompt: '',
    negativePrompt: DEFAULT_NEGATIVE_PROMPT,
    settings: DEFAULT_SETTINGS,
    theme: 'dark',
  };
}

// Save history
export function saveHistory(history: HistoryItem[]): void {
  if (typeof window === 'undefined') return;
  
  // Limit to 50 items and don't store full image data for efficiency
  const limitedHistory = history.slice(0, 50).map(item => ({
    ...item,
    // Store thumbnail only if it's a small base64 or a URL
    sourceImage: item.sourceImage.length > 50000 
      ? item.sourceImage.substring(0, 500) + '...' 
      : item.sourceImage,
  }));
  
  localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(limitedHistory));
}

// Get history
export function getHistory(): HistoryItem[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load history:', e);
  }
  
  return [];
}

// Save favorites
export function saveFavorites(favorites: string[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
}

// Get favorites
export function getFavorites(): string[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load favorites:', e);
  }
  
  return [];
}

// Clear all storage
export function clearAllStorage(): void {
  if (typeof window === 'undefined') return;
  
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}

// Export settings as JSON file
export function exportAsJson(data: object, filename: string): void {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Import settings from JSON file
export function importFromJson(file: File): Promise<GenerationSettings | null> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const json = e.target?.result as string;
        const data = JSON.parse(json);
        resolve(data as GenerationSettings);
      } catch (error) {
        console.error('Failed to parse JSON file:', error);
        resolve(null);
      }
    };
    
    reader.onerror = () => resolve(null);
    reader.readAsText(file);
  });
}
