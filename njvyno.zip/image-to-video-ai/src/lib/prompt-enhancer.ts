// Comprehensive prompt enhancement system

export interface PromptEnhancement {
  original: string;
  enhanced: string;
  motionTerms: string[];
  weightedTerms: string[];
  expansions: string[];
  warnings: string[];
  suggestions: string[];
}

// Motion keywords based on video duration
const MOTION_KEYWORDS = {
  short: [
    'subtle motion',
    'gentle movement',
    'natural micro-expressions',
    'smooth transition',
    'minimal but natural movement',
  ],
  long: [
    'smooth continuous motion',
    'natural progression',
    'realistic pacing',
    'fluid movement',
    'gradual natural motion',
  ],
};

// Camera stability terms
const CAMERA_TERMS = [
  'stable camera',
  'fixed perspective',
  'no camera shake',
  'steady shot',
  'tripod stability',
];

// Common motion expansions
const MOTION_EXPANSIONS: Record<string, string[]> = {
  'smiling': [
    'natural smile forming',
    'facial muscles engaging realistically',
    'genuine expression',
    'lips curving upward naturally',
    'eyes crinkling with smile',
  ],
  'looking at camera': [
    'making eye contact with viewer',
    'gaze directed forward',
    'eyes focused on lens',
    'direct eye contact',
  ],
  'waving': [
    'hand waving motion',
    'arm raising smoothly',
    'natural wave gesture',
    'fingers moving in wave pattern',
  ],
  'turning head': [
    'smooth head rotation',
    'natural neck movement',
    'gradual head turn',
    'face rotating smoothly',
  ],
  'walking': [
    'natural walking gait',
    'realistic leg movement',
    'proper weight shifting',
    'smooth stride',
  ],
  'blinking': [
    'eyelids closing smoothly',
    'brief natural eye closure',
    'natural blink motion',
    'eyes reopening naturally',
  ],
  'talking': [
    'lips moving naturally',
    'realistic speech animation',
    'mouth forming words',
    'natural lip sync',
  ],
  'breathing': [
    'chest rising gently',
    'natural breath rhythm',
    'subtle breathing motion',
    'realistic respiratory movement',
  ],
  'grab': [
    'hand reaching smoothly',
    'fingers extending naturally',
    'grasping motion',
    'hand closing around object',
  ],
  'touching': [
    'hand approaching gently',
    'fingers making contact',
    'light touch motion',
    'tactile interaction',
  ],
  'nodding': [
    'head moving up and down',
    'natural nod gesture',
    'chin dipping slightly',
    'affirmative head motion',
  ],
  'shaking head': [
    'head turning side to side',
    'natural head shake',
    'horizontal head movement',
    'negative gesture motion',
  ],
  'laughing': [
    'natural laugh expression',
    'shoulders shaking slightly',
    'genuine amusement showing',
    'smile widening with laugh',
  ],
  'crying': [
    'tears forming naturally',
    'emotional expression',
    'facial muscles showing sadness',
    'eyes watering realistically',
  ],
};

// Ambiguous terms that need clarification
const AMBIGUOUS_TERMS: Record<string, string> = {
  'moving': 'Specify what should move and how (e.g., "head moving slowly left" or "hand moving up")',
  'looking': 'Specify direction (e.g., "looking left", "looking at camera", "looking down")',
  'turning': 'Specify what turns and direction (e.g., "head turning left", "body turning around")',
  'hand gesture': 'Specify the gesture type (e.g., "waving", "pointing", "thumbs up")',
  'expression': 'Specify the emotion (e.g., "happy expression", "surprised expression")',
  'action': 'Be specific about the action (e.g., "raising hand", "stepping forward")',
};

// Terms that improve video quality
const QUALITY_ENHANCERS = [
  'realistic',
  'natural',
  'smooth',
  'fluid',
  'cinematic',
  'high quality',
  'detailed',
  'professional',
];

/**
 * Main prompt enhancement function
 */
export function enhancePrompt(
  originalPrompt: string,
  options: {
    duration?: 5 | 10;
    addCameraStability?: boolean;
    addMotionTerms?: boolean;
    useWeights?: boolean;
  } = {}
): PromptEnhancement {
  const {
    duration = 5,
    addCameraStability = true,
    addMotionTerms = true,
    useWeights = true,
  } = options;

  const motionTerms: string[] = [];
  const weightedTerms: string[] = [];
  const expansions: string[] = [];
  const warnings: string[] = [];
  const suggestions: string[] = [];

  let enhanced = originalPrompt.trim();

  // Check for ambiguous terms
  const promptLower = enhanced.toLowerCase();
  for (const [term, suggestion] of Object.entries(AMBIGUOUS_TERMS)) {
    if (promptLower.includes(term)) {
      suggestions.push(suggestion);
    }
  }

  // Apply motion expansions
  for (const [keyword, expansionsList] of Object.entries(MOTION_EXPANSIONS)) {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    if (regex.test(enhanced)) {
      const expansion = expansionsList.slice(0, 2).join(', ');
      if (!enhanced.toLowerCase().includes(expansion.toLowerCase())) {
        expansions.push(`${keyword} → ${expansion}`);
        enhanced = enhanced + ', ' + expansion;
      }
    }
  }

  // Add motion terms based on duration
  if (addMotionTerms) {
    const motionKeywords = duration === 5 ? MOTION_KEYWORDS.short : MOTION_KEYWORDS.long;
    const selectedMotion = motionKeywords.slice(0, 2);
    motionTerms.push(...selectedMotion);
    enhanced = enhanced + ', ' + selectedMotion.join(', ');
  }

  // Add camera stability terms
  if (addCameraStability) {
    enhanced = enhanced + ', ' + CAMERA_TERMS.slice(0, 2).join(', ');
  }

  // Add quality enhancers if not present
  const hasQualityTerms = QUALITY_ENHANCERS.some(q => promptLower.includes(q));
  if (!hasQualityTerms) {
    enhanced = enhanced + ', natural movement, realistic physics';
  }

  // Apply weights to key terms
  if (useWeights) {
    // Find key subjects (usually first nouns)
    const words = enhanced.split(/[\s,]+/);
    const keyTerms = words.slice(0, 5).filter(w => w.length > 3);
    
    if (keyTerms.length > 0) {
      // Weight the most important terms
      const weighted = keyTerms.slice(0, 3).map((term, i) => {
        const weight = 1.5 - (i * 0.1);
        return `(${term}:${weight.toFixed(1)})`;
      });
      weightedTerms.push(...weighted);
    }
  }

  // Check for potential issues
  if (enhanced.length > 500 && enhanced.length < 2000) {
    suggestions.push('Consider breaking very long prompts into key elements only');
  }

  if (enhanced.split(',').length > 20) {
    warnings.push('Many terms may dilute prompt focus - consider prioritizing');
  }

  return {
    original: originalPrompt,
    enhanced: enhanced,
    motionTerms,
    weightedTerms,
    expansions,
    warnings,
    suggestions,
  };
}

/**
 * Enhance negative prompt
 */
export function enhanceNegativePrompt(
  originalNegative: string
): { enhanced: string; additions: string[] } {
  const additions: string[] = [];
  let enhanced = originalNegative;

  // Essential terms that should always be present
  const essentialTerms = [
    'unnatural movement',
    'jerky motion',
    'robotic behavior',
    'frozen face',
    'stiff animation',
    'glitchy movement',
  ];

  const negativeLower = enhanced.toLowerCase();
  for (const term of essentialTerms) {
    if (!negativeLower.includes(term.toLowerCase())) {
      additions.push(term);
      enhanced = enhanced + ', ' + term;
    }
  }

  return { enhanced, additions };
}

/**
 * Generate prompt variations for multiple attempts
 */
export function generatePromptVariations(
  basePrompt: string,
  count: number = 3
): string[] {
  const variations: string[] = [];
  
  // Variation 1: Direct and focused
  variations.push(basePrompt);
  
  // Variation 2: Emphasize motion
  variations.push(basePrompt + ', fluid continuous motion, natural movement progression');
  
  // Variation 3: Add temporal structure
  variations.push(basePrompt + ', starting slowly then building naturally, realistic timing');
  
  return variations.slice(0, count);
}

/**
 * Analyze prompt for potential issues
 */
export function analyzePromptQuality(prompt: string): {
  score: number;
  issues: string[];
  strengths: string[];
} {
  const issues: string[] = [];
  const strengths: string[] = [];
  let score = 100;

  const promptLower = prompt.toLowerCase();

  // Check length
  if (prompt.length < 20) {
    issues.push('Very short prompt - add more detail');
    score -= 20;
  } else if (prompt.length > 500) {
    issues.push('Very long prompt - may lose focus');
    score -= 10;
  } else if (prompt.length >= 50 && prompt.length <= 200) {
    strengths.push('Good prompt length');
  }

  // Check for motion words
  const motionWords = ['move', 'turn', 'walk', 'smile', 'look', 'wave', 'blink', 'nod'];
  const hasMotion = motionWords.some(w => promptLower.includes(w));
  if (!hasMotion) {
    issues.push('No motion keywords detected - describe what should move');
    score -= 15;
  } else {
    strengths.push('Contains motion keywords');
  }

  // Check for quality terms
  const hasQuality = QUALITY_ENHANCERS.some(q => promptLower.includes(q));
  if (hasQuality) {
    strengths.push('Contains quality descriptors');
  }

  // Check for specific timing
  const hasTiming = /\b(slow|fast|gentle|quick|gradual|sudden)\b/i.test(prompt);
  if (!hasTiming) {
    suggestions.push('Consider adding timing (slow, fast, gentle, gradual)');
    score -= 5;
  }

  // Check for camera direction
  const hasCamera = /\b(zoom|pan|tilt|camera|static|moving)\b/i.test(prompt);
  if (!hasCamera) {
    issues.push('No camera direction specified');
    score -= 5;
  }

  return {
    score: Math.max(0, score),
    issues,
    strengths,
  };
}

const suggestions: string[] = [];

/**
 * Create fallback enhanced prompt for regeneration
 */
export function createFallbackPrompt(originalPrompt: string): string {
  // 3x more descriptive version
  const enhanced = enhancePrompt(originalPrompt, {
    duration: 5,
    addCameraStability: true,
    addMotionTerms: true,
    useWeights: true,
  });

  // Add extra emphasis
  const fallback = `
    ${enhanced.enhanced}, 
    explicitly performing the described action, 
    clear unmistakable motion, 
    highly detailed movement, 
    precise execution of motion,
    real-time speed,
    natural physics,
    accurate anatomy,
    proper timing,
    smooth execution
  `.replace(/\s+/g, ' ').trim();

  return fallback;
}
