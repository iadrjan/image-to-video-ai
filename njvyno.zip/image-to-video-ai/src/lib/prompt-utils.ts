// Prompt utilities for handling long prompts and validation

export interface PromptAnalysis {
  positiveLength: number;
  negativeLength: number;
  warnings: PromptWarning[];
  suggestions: string[];
  estimatedTokens: number;
  willBeTruncated: boolean;
  filteredTerms: string[];
  contradictoryTerms: string[];
}

export interface PromptWarning {
  type: 'length' | 'filter' | 'contradiction' | 'syntax' | 'redundancy';
  severity: 'info' | 'warning' | 'error';
  message: string;
  details?: string;
}

// Terms that might trigger content filters (but are legitimate for negative prompts)
const POTENTIALLY_FILTERED_TERMS = [
  'naked', 'nude', 'exposed', 'skin', 'body', 'breast', 'chest', 'butt',
  'sexual', 'erotic', 'sensual', 'intimate', 'provocative',
  'blood', 'gore', 'violence', 'death', 'kill', 'murder',
  'drug', 'alcohol', 'smoking', 'weapon', 'gun', 'knife',
];

// API limits (adjust based on actual API)
const API_LIMITS = {
  maxPromptLength: 10000,  // Per prompt field
  maxTotalLength: 20000,   // Combined
  warnLength: 5000,        // Show warning at this length
};

/**
 * Analyze prompts for potential issues
 */
export function analyzePrompts(
  positivePrompt: string,
  negativePrompt: string
): PromptAnalysis {
  const warnings: PromptWarning[] = [];
  const suggestions: string[] = [];
  const filteredTerms: string[] = [];
  const contradictoryTerms: string[] = [];

  // Check lengths
  const positiveLength = positivePrompt.length;
  const negativeLength = negativePrompt.length;
  const totalLength = positiveLength + negativeLength;

  // Length warnings
  if (negativeLength > API_LIMITS.warnLength) {
    warnings.push({
      type: 'length',
      severity: 'warning',
      message: `Negative prompt is very long (${negativeLength.toLocaleString()} characters)`,
      details: 'Some terms may be condensed to fit API limits.',
    });
  }

  if (totalLength > API_LIMITS.maxTotalLength) {
    warnings.push({
      type: 'length',
      severity: 'error',
      message: `Combined prompts exceed API limit (${totalLength.toLocaleString()} / ${API_LIMITS.maxTotalLength.toLocaleString()} chars)`,
      details: 'The prompt will be truncated. Consider removing less important terms.',
    });
  }

  if (positiveLength > API_LIMITS.maxPromptLength) {
    warnings.push({
      type: 'length',
      severity: 'warning',
      message: `Positive prompt exceeds typical API limit (${positiveLength.toLocaleString()} chars)`,
      details: 'The prompt may be truncated by the API.',
    });
  }

  // Check for potentially filtered terms in negative prompt (these are OK but user should know)
  const negativeLower = negativePrompt.toLowerCase();
  for (const term of POTENTIALLY_FILTERED_TERMS) {
    if (negativeLower.includes(term)) {
      filteredTerms.push(term);
    }
  }

  if (filteredTerms.length > 0) {
    warnings.push({
      type: 'filter',
      severity: 'info',
      message: `Negative prompt contains terms that might trigger content filters`,
      details: `Terms: ${filteredTerms.slice(0, 5).join(', ')}${filteredTerms.length > 5 ? '...' : ''}. These are for PREVENTION and should be allowed.`,
    });
    suggestions.push('These terms in negative prompts help prevent unwanted content. They should be accepted by the API.');
  }

  // Check for contradictions (same term in positive and negative)
  const positiveWords = new Set(
    positivePrompt.toLowerCase().split(/\s+/).filter(w => w.length > 3)
  );
  const negativeWords = new Set(
    negativePrompt.toLowerCase().split(/\s+/).filter(w => w.length > 3)
  );

  for (const word of positiveWords) {
    if (negativeWords.has(word)) {
      contradictoryTerms.push(word);
    }
  }

  if (contradictoryTerms.length > 0) {
    warnings.push({
      type: 'contradiction',
      severity: 'warning',
      message: `Found ${contradictoryTerms.length} terms in both positive and negative prompts`,
      details: `Examples: ${contradictoryTerms.slice(0, 5).join(', ')}`,
    });
    suggestions.push('Contradictory terms may confuse the model. Consider removing from one side.');
  }

  // Check for redundant terms in negative prompt
  const negativeTerms = negativePrompt.toLowerCase().split(',').map(t => t.trim());
  const seen = new Map<string, number>();
  const redundancies: string[] = [];

  for (const term of negativeTerms) {
    const normalized = term.replace(/[^a-z]/g, '');
    if (normalized.length < 3) continue;
    
    if (seen.has(normalized)) {
      redundancies.push(term);
    } else {
      seen.set(normalized, 1);
    }
  }

  if (redundancies.length > 3) {
    warnings.push({
      type: 'redundancy',
      severity: 'info',
      message: `Found ${redundancies.length} potentially redundant terms in negative prompt`,
      details: 'Some terms appear multiple times with slight variations.',
    });
    suggestions.push('Removing redundant terms can help fit more content within API limits.');
  }

  // Estimate tokens (rough approximation: ~4 chars per token)
  const estimatedTokens = Math.ceil(totalLength / 4);

  return {
    positiveLength,
    negativeLength,
    warnings,
    suggestions,
    estimatedTokens,
    willBeTruncated: totalLength > API_LIMITS.maxTotalLength,
    filteredTerms: [...new Set(filteredTerms)],
    contradictoryTerms: [...new Set(contradictoryTerms)],
  };
}

/**
 * Smart truncation for long prompts
 * Prioritizes keeping all unique terms, removes redundancies first
 */
export function smartTruncatePrompt(
  prompt: string,
  maxLength: number,
  priority: 'start' | 'end' | 'important' = 'important'
): { truncated: string; wasTruncated: boolean; removedTerms: string[] } {
  if (prompt.length <= maxLength) {
    return { truncated: prompt, wasTruncated: false, removedTerms: [] };
  }

  const removedTerms: string[] = [];
  const terms = prompt.split(',').map(t => t.trim());
  
  // Remove duplicate/similar terms first
  const seen = new Set<string>();
  const uniqueTerms: string[] = [];

  for (const term of terms) {
    const normalized = term.toLowerCase().replace(/[^a-z0-9\s]/g, '');
    const key = normalized.split(/\s+/).sort().join(' ');
    
    if (!seen.has(key) && term.length > 0) {
      seen.add(key);
      uniqueTerms.push(term);
    } else {
      removedTerms.push(term);
    }
  }

  // Build truncated prompt
  let result = uniqueTerms.join(', ');
  
  // If still too long, truncate from end
  if (result.length > maxLength) {
    // Keep as many complete terms as possible
    const keptTerms: string[] = [];
    let currentLength = 0;

    for (const term of uniqueTerms) {
      if (currentLength + term.length + 2 <= maxLength) {
        keptTerms.push(term);
        currentLength += term.length + 2;
      } else {
        removedTerms.push(term);
      }
    }

    result = keptTerms.join(', ');
  }

  return {
    truncated: result,
    wasTruncated: true,
    removedTerms,
  };
}

/**
 * Prepare prompts for API submission
 * Returns the exact strings that will be sent
 */
export function preparePromptsForApi(
  positivePrompt: string,
  negativePrompt: string,
  settings: {
    motionIntensity?: number;
  } = {}
): {
  finalPositivePrompt: string;
  finalNegativePrompt: string;
  modifications: string[];
  warnings: string[];
} {
  const modifications: string[] = [];
  const warnings: string[] = [];

  let finalPositivePrompt = positivePrompt.trim();
  let finalNegativePrompt = negativePrompt.trim();

  // Add motion intensity terms if not default (5)
  if (settings.motionIntensity && settings.motionIntensity !== 5) {
    const motionTerms: Record<number, string> = {
      1: 'subtle, minimal motion, gentle, calm',
      2: 'gentle motion, soft movement',
      3: 'light movement, smooth transition',
      4: 'moderate motion, natural movement',
      6: 'dynamic motion, active movement',
      7: 'energetic motion, lively movement',
      8: 'strong motion, pronounced movement',
      9: 'intense motion, dramatic movement',
      10: 'extreme motion, powerful dynamic movement',
    };

    const motionTerm = motionTerms[settings.motionIntensity];
    if (motionTerm) {
      finalPositivePrompt = `${finalPositivePrompt}, ${motionTerm}`;
      modifications.push(`Added motion intensity terms: "${motionTerm}"`);
    }
  }

  // Check if truncation is needed
  const totalLength = finalPositivePrompt.length + finalNegativePrompt.length;
  
  if (totalLength > API_LIMITS.maxTotalLength) {
    // Smart truncate negative prompt first (keep positive intact)
    const availableForNegative = API_LIMITS.maxTotalLength - finalPositivePrompt.length - 100;
    
    if (availableForNegative > 1000) {
      const result = smartTruncatePrompt(finalNegativePrompt, availableForNegative);
      if (result.wasTruncated) {
        warnings.push(`Negative prompt was condensed. Removed ${result.removedTerms.length} redundant/similar terms.`);
        modifications.push(`Truncated negative prompt from ${finalNegativePrompt.length} to ${result.truncated.length} chars`);
        finalNegativePrompt = result.truncated;
      }
    }
  }

  return {
    finalPositivePrompt,
    finalNegativePrompt,
    modifications,
    warnings,
  };
}

/**
 * Format prompt for display
 */
export function formatPromptForDisplay(prompt: string, maxLength: number = 500): string {
  if (prompt.length <= maxLength) {
    return prompt;
  }
  return prompt.substring(0, maxLength) + `... (${prompt.length - maxLength} more characters)`;
}

/**
 * Get severity color
 */
export function getSeverityColor(severity: 'info' | 'warning' | 'error'): string {
  switch (severity) {
    case 'error':
      return 'text-red-500';
    case 'warning':
      return 'text-yellow-500';
    case 'info':
      return 'text-blue-500';
    default:
      return 'text-muted-foreground';
  }
}

/**
 * Get severity badge variant
 */
export function getSeverityVariant(severity: 'info' | 'warning' | 'error'): 'default' | 'secondary' | 'destructive' {
  switch (severity) {
    case 'error':
      return 'destructive';
    case 'warning':
      return 'default';
    case 'info':
    default:
      return 'secondary';
  }
}
