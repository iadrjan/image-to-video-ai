// Video Generation Types

export type VideoTaskStatus = 'PENDING' | 'PROCESSING' | 'SUCCESS' | 'FAIL' | 'CANCELLED';

export type QualityMode = 'speed' | 'quality';

export type VideoDuration = 5 | 10;

export type VideoFps = 30 | 60;

export interface VideoResolution {
  label: string;
  value: string;
  width: number;
  height: number;
}

export const VIDEO_RESOLUTIONS: VideoResolution[] = [
  { label: '720p (HD)', value: '1280x720', width: 1280, height: 720 },
  { label: '1080p (Full HD)', value: '1920x1080', width: 1920, height: 1080 },
  { label: 'Square (1:1)', value: '1024x1024', width: 1024, height: 1024 },
  { label: 'Portrait (2:1)', value: '720x1440', width: 720, height: 1440 },
  { label: 'Landscape (1:2)', value: '1440x720', width: 1440, height: 720 },
];

export interface GenerationSettings {
  duration: VideoDuration;
  fps: VideoFps;
  resolution: string;
  quality: QualityMode;
  motionIntensity: number;
  seed: number | null;
}

export const DEFAULT_SETTINGS: GenerationSettings = {
  duration: 5,
  fps: 30,
  resolution: '1920x1080',
  quality: 'quality',
  motionIntensity: 5,
  seed: null,
};

export interface VideoGenerationTask {
  id: string;
  taskId: string | null;
  status: VideoTaskStatus;
  positivePrompt: string;
  negativePrompt: string;
  settings: GenerationSettings;
  sourceImage: string;
  videoUrl: string | null;
  thumbnailUrl: string | null;
  createdAt: Date;
  completedAt: Date | null;
  progress: number;
  error: string | null;
  isFavorite: boolean;
}

export interface HistoryItem {
  id: string;
  taskId: string;
  sourceImage: string;
  videoUrl: string;
  positivePrompt: string;
  negativePrompt: string;
  settings: GenerationSettings;
  createdAt: Date;
  isFavorite: boolean;
}

export interface UserPreferences {
  positivePrompt: string;
  negativePrompt: string;
  settings: GenerationSettings;
  theme: 'light' | 'dark' | 'system';
}

export const PROMPT_TEMPLATES = [
  {
    name: 'Natural Movement',
    prompt: 'Natural movement and realistic motion, the subject moves naturally with subtle breathing and blinking, cinematic quality',
  },
  {
    name: 'Camera Pan',
    prompt: 'Smooth camera pan from left to right, cinematic movement, professional cinematography, gentle motion',
  },
  {
    name: 'Zoom In',
    prompt: 'Gentle zoom in with ambient motion, focus on the main subject, cinematic depth of field, realistic movement',
  },
  {
    name: 'Dynamic Action',
    prompt: 'Dynamic action with realistic physics, fast-paced movement, high energy motion, cinematic action sequence',
  },
  {
    name: 'Cinematic',
    prompt: 'Cinematic quality with natural lighting, film grain, professional cinematography, atmospheric mood, subtle motion',
  },
  {
    name: 'Portrait Animation',
    prompt: 'Portrait animation with natural facial expressions, subtle eye movement, gentle head turn, lifelike appearance',
  },
  {
    name: 'Landscape Motion',
    prompt: 'Landscape scene with natural wind effects, moving clouds, swaying vegetation, atmospheric movement',
  },
  {
    name: 'Product Showcase',
    prompt: 'Product showcase with smooth rotation, professional lighting, clean background, commercial quality',
  },
];

export const DEFAULT_NEGATIVE_PROMPT = `slow motion, slomo, slow-mo, slow mo, slow motion effect, bullet time, freeze frame, time dilation, dreamlike pace, underwater movement, heavy gravity, molasses, sluggish, lethargic, dragging, plodding, lumbering, heavy, ponderous, labored movement, unnatural delay, artificial slowdown, video effect slowmo, fake slow motion, stuttering slow motion, choppy slow motion, bad slow motion, plastic skin, rubber skin, silicone skin, wax skin, doll skin, mannequin skin, synthetic skin, artificial texture, shiny skin, glossy skin, waxy appearance, plasticine, clay skin, uncanny valley skin, overly smooth skin, poreless skin, airbrushed effect, fake complexion, artificial smoothness, plastic surgery face, botox face, frozen face, mask-like face, unnatural smoothness, stretched skin, pulled skin, tight skin, strange eyes, weird eyes, googly eyes, crossed eyes, wall-eyed, dead eyes, glassy eyes, doll eyes, shark eyes, pupil dilation issues, mismatched pupils, uneven eyes, asymmetrical eyes, asymmetrical irises, floating pupils, misplaced pupils, sliding pupils, rotating pupils, non-circular pupils, uneven pupils, misshapen pupils, square pupils, weirdly shaped pupils, broken eye contact, looking through people, looking away, averting gaze, shifty eyes, darting eyes, unfocused eyes, lazy eye, wandering eye, bulging eyes, sunken eyes, hollow eyes, blank stare, thousand-yard stare, empty eyes, lifeless eyes, soulless eyes, unblinking eyes, rapid blinking, twitching eyes, crossed eyes, wall-eyed, divergent gaze, unnatural hair movement, floating hair, gravity-defying hair, plastic hair, helmet hair, wig-like hair, unnatural shine, excessive glossiness, weird reflections, floating clothing, clipping clothing, clothing passing through body, clothing passing through objects, wrong clothing physics, stiff clothing, rigid fabric, unnatural draping, impossible wrinkles, missing wrinkles, wrong wrinkles, broken physics, floating objects, objects passing through each other, clipping, collision errors, wrong gravity, weightless objects, objects falling wrong, floating debris, hovering objects, impossible movement, physics violations, wrong momentum, incorrect inertia, fake grip, floating grip, phantom grip, wrong hand position, hands not touching objects, objects floating near hands, wrong finger placement, unnatural grip strength, impossible grip angles, hands passing through objects, wrong object contact, bad object interaction, stiff expression, frozen expression, mask face, wooden face, lifeless expression, dead face, emotionless, blank expression, robotic face, mannequin expression, limited expression range, stiff jaw, locked jaw, frozen mouth, rigid features, tension in face, unnatural smile, forced smile, fake smile, AI generated, AI artifacts, generated looking, artificial, synthetic, computer generated, deepfake, manipulated, edited, filtered, processed, overprocessed, quality degradation, compression artifacts, banding, posterization, noise, grain, blur, soft focus, wrong focus, depth of field errors, chromatic aberration, lens distortion, perspective errors, unnatural perspective, wrong proportions, stretched, squashed, distorted, warped, deformed, mangled, broken anatomy, extra limbs, missing limbs, wrong limb placement, floating limbs, disconnected limbs, extra fingers, missing fingers, wrong finger count, fused fingers, malformed hands, claw hands, robot hands, extra joints, wrong joints, bending wrong, impossible pose, unnatural pose, weird position, uncanny, creepy, horror, nightmare fuel, disturbing, off-putting, wrong, incorrect, error, glitch, artifact, defect, flaw, issue, problem`;
